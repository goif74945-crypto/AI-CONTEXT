# 01 — Manifest and Task Contract

## Task contract

### Objective
Design, implement, test, and document a standalone supplemental reference system that can compile explicit information-handling policy and an information-flow request into one deterministic `ALLOW`, `DENY`, or `FREEZE` decision.

### Required output
- architecture/specification;
- machine-readable schemas;
- reference compiler;
- scenario corpus;
- executable unit/adversarial tests;
- validation harness and evidence;
- threat/failure model;
- integration proposal;
- adoption gates;
- future research backlog;
- resumable execution memory and final audit.

### Authorized scope
Only the new NIBC directory under `AI-CONTEXT/คลังข้อมูลเสริม`.

### Protected scope
Any NEXY.AI-named repository, existing sibling supplemental artifacts, canonical matrices/specs, production/deployment state, secrets.

### Authority sources
1. current user directive;
2. AI-CONTEXT execution/security/verification rules;
3. NEXY project context in AI-CONTEXT;
4. this project as AI-proposed advisory material.

### Success invariants
- deterministic decision for identical explicit inputs;
- unknown material identities/authority/conflicts freeze;
- explicit policy prohibition denies;
- external disclosure cannot bypass consent/user-authority requirements;
- retention may not be silently lengthened or clipped into success;
- minimization produces an explicit transform plan;
- deletion requires target identity and explicit authority;
- critical decisions carry audit/proof obligations;
- prototype contains no secrets and performs no hidden external I/O.

### Required evidence
- E1 parser/syntax/schema validation;
- E2 unit/adversarial tests;
- E0 post-publication read-back.

### Stop conditions
Freeze publication if:
- target repo/path is not AI-CONTEXT/new NIBC folder;
- any protected NEXY.AI repo would be mutated;
- write preconditions become ambiguous;
- local E1/E2 validation fails;
- source/test/evidence content diverges after validation without re-run.

## Artifact manifest

| Path | Role |
|---|---|
| `src/nibc.py` | deterministic reference compiler |
| `tests/test_nibc.py` | E2 unit/adversarial tests |
| `fixtures/base_policy.json` | example policy |
| `fixtures/scenarios.json` | scenario corpus |
| `schemas/policy.schema.json` | policy contract schema |
| `schemas/request.schema.json` | request contract schema |
| `schemas/decision.schema.json` | decision output schema |
| `tools/validate.py` | E1/E2 validation harness |
| `execution-evidence.json` | raw local validation evidence + critical hashes |
| `requirements-dev.txt` | pinned dev-only validation dependency |
| `02_ARCHITECTURE.md` | architecture and state model |
| `03_REQUIREMENT_LEDGER.md` | requirement → implementation → evidence map |
| `04_POLICY_CONTRACT.md` | semantics of policy/request/decision |
| `05_THREAT_FAILURE_MODEL.md` | threats, failure classes, responses |
| `06_INTEGRATION_PROPOSAL.md` | non-governing future integration concept |
| `07_ADOPTION_GATES.md` | requirements before promotion |
| `08_RESEARCH_BACKLOG.md` | future experiments |
| `09_VALIDATION_REPORT.md` | evidence summary |
| `10_FINAL_AUDIT.md` | completion audit and limitations |
