# 02 — Architecture

Status: AI_PROPOSED_CONCEPT

## 1. Problem

A multi-model control hub can be logically correct and still mishandle information if it lacks a deterministic answer to questions such as:

- May this datum leave the local boundary?
- Is this purpose compatible with why the datum exists?
- Does the destination have enough clearance?
- Is external disclosure authorized and consented?
- Is durable retention permitted, for how long, and with what expiry obligations?
- Which fields are actually necessary for this purpose?
- Is deletion authorized and can its completion be evidenced?
- What happens when two policy rules of equal authority disagree?

NIBC treats those questions as a compile problem rather than ad-hoc prompt wording.

## 2. Architectural position

Conceptual only:

```text
Normalized task/context
        |
        v
Information Flow Request
        |
        v
+-------------------------------+
| NIBC POLICY COMPILER          |
| 1 contract validation         |
| 2 identity/classification     |
| 3 sensitivity clearance      |
| 4 purpose/operation/dest      |
| 5 rule authority/conflict    |
| 6 consent + user authority   |
| 7 retention/persistence      |
| 8 minimization               |
| 9 provenance                 |
+-------------------------------+
        |
        +----> DENY
        |
        +----> FREEZE
        |
        v
ALLOW + transforms + obligations
        |
        v
Actual executor / agent / tool / vault adapter
```

NIBC does **not** execute disclosure itself. It emits a boundary decision that a future trusted executor would have to enforce.

## 3. Trust boundary

Inputs are data, not authority by themselves. Policy is the governing input to this reference compiler; requests may not rewrite policy in-band.

The compiler has no model call and no implicit fallback. A model may suggest a policy draft in a future system, but that draft would require independent admission before becoming authoritative.

## 4. Deterministic state model

Conceptual pipeline:

```text
RECEIVED
  -> CONTRACT_VALIDATED
  -> IDENTITIES_RESOLVED
  -> CLEARANCE_RESOLVED
  -> PURPOSE_RESOLVED
  -> RULES_RESOLVED
  -> AUTHORITY_RESOLVED
  -> PERSISTENCE_RESOLVED
  -> MINIMIZED
  -> PROVENANCE_RESOLVED
  -> RELEASED(ALLOW)
```

Side exits:

- `DENIED` when an explicit controlling policy blocks the action;
- `FROZEN` when required material state is unknown, malformed, or conflicting.

No `best_effort_allow` state exists.

## 5. Decision precedence

The reference implementation uses this order:

1. validate policy/request contract;
2. resolve data class and destination;
3. enforce sensitivity clearance;
4. enforce purpose;
5. enforce operation;
6. enforce destination allow-list;
7. evaluate explicit rules;
8. require consent where configured for external boundaries;
9. require user authority where configured for external boundaries;
10. enforce durable-storage and retention rules;
11. enforce deletion target/authority and attach deletion-proof obligations;
12. compile field minimization transforms;
13. require provenance;
14. release `ALLOW` with audit obligation.

Important property: an explicit `ALLOW` rule in this prototype can add transforms/obligations but does not bypass later mandatory gates. A `DENY` rule can terminate earlier. Equal-priority `ALLOW`/`DENY` conflict freezes.

## 6. Information model

### Data class
Defines:
- sensitivity;
- allowed purposes;
- allowed operations;
- allowed destinations;
- external consent/authority requirements;
- durable-storage permission;
- retention maximum;
- provenance requirement;
- per-purpose field allow-list.

### Destination
Defines:
- maximum accepted sensitivity;
- whether the boundary is external;
- whether it is durable.

### Request
Carries explicit:
- data class;
- purpose;
- operation;
- destination;
- field names;
- consent state if relevant;
- user authority if relevant;
- requested retention if storing;
- resource identity if deleting;
- provenance.

### Decision
Carries:
- deterministic decision ID;
- `ALLOW|DENY|FREEZE`;
- reason code;
- explicit transforms;
- enforcement obligations;
- decision trace;
- policy identity/version.

## 7. Determinism contract

The decision core uses only provided objects and deterministic JSON canonicalization for the decision ID.

Forbidden implicit inputs in the core:
- wall clock;
- random numbers;
- environment variables;
- filesystem;
- network;
- database;
- model output;
- hidden process state.

Any future time-aware rule must receive time as an explicit normalized input rather than calling a clock inside the deterministic core.

## 8. Failure semantics

- missing identity → `FREEZE`;
- policy prohibition → `DENY`;
- missing consent when required → `FREEZE`;
- explicit consent denial → `DENY`;
- missing explicit user authority when required → `FREEZE`;
- explicit authority denial → `DENY`;
- over-retention → `DENY` rather than silently reducing the retention request;
- equal-authority contradictory rule → `FREEZE`;
- malformed contract → `FREEZE`.

## 9. Observability contract

The compiler returns a structured trace of gates reached and the final reason code. A future runtime should log only the minimum decision metadata required for audit, not raw protected payload by default.

## 10. Performance direction

The prototype is intentionally small and pure. Production integration should preserve bounded work proportional to policy/rule count and requested field count. Large semantic classifiers belong outside this deterministic gate and must not silently become authority.
