# 07 — Adoption Gates

No NIBC concept should be promoted into canonical NEXY implementation merely because the reference prototype passes E1/E2.

## Gate sequence

| Gate | Required proof | Current |
|---|---|---|
| G0 Authority | explicit project/user approval to evaluate adoption | NOT_VERIFIED |
| G1 Taxonomy | canonical data classes, destinations, purposes, authority sources defined | NOT_VERIFIED |
| G2 Policy governance | owner, versioning, supersession, conflict resolution, rollback specified | NOT_VERIFIED |
| G3 Adapter contract | every disclosure/persistence/export/delete boundary enumerated | NOT_VERIFIED |
| G4 Transform enforcement | redaction/minimization executor proves exact transformed payload | NOT_VERIFIED |
| G5 Storage lifecycle | retention expiry and deletion across all stores/providers proven | NOT_VERIFIED |
| G6 Abuse tests | forged authority, stale policy, injection, destination drift, bypass tested | NOT_VERIFIED |
| G7 Integration tests | NIBC + real context/model/tool/vault adapters executed | NOT_VERIFIED |
| G8 E2E UX | user can understand allow/deny/freeze/consent/deletion flows | NOT_VERIFIED |
| G9 Runtime observability | decision IDs, obligation completion, failures observable without data leakage | NOT_VERIFIED |
| G10 Legal/privacy review | target-jurisdiction requirements evaluated by appropriate authority | NOT_VERIFIED |
| G11 Migration | existing stored data classified and retention/deletion rules safely migrated | NOT_VERIFIED |
| G12 Release evidence | exact build/environment proof meets project release law | NOT_VERIFIED |

## Freeze rule

If any adoption decision depends on an unresolved gate, status remains `NOT_VERIFIED` or `BLOCKED`; do not convert the reference prototype into a production claim.

## Recommended pilot

If authorized later, begin with the lowest-risk boundary:
- explicit data class;
- local deterministic policy;
- read-only disclosure decision;
- no durable mutation;
- synthetic fixtures;
- full trace capture.

Only expand after exact behavior and bypass resistance are proven.
