# 03 — Requirement Ledger

Status labels follow AI-CONTEXT verification law.

| ID | Requirement | Implementation | Evidence | Status |
|---|---|---|---|---|
| NIBC-R001 | Same explicit policy + request yields identical decision object | canonical JSON + SHA-256 decision ID | `test_deterministic_decision_id` | PASS (E2) |
| NIBC-R002 | Unknown data class freezes | `UNKNOWN_DATA_CLASS` | unit test | PASS (E2) |
| NIBC-R003 | Unknown destination freezes | `UNKNOWN_DESTINATION` | unit test | PASS (E2) |
| NIBC-R004 | Destination clearance cannot be exceeded | sensitivity order comparison | unit + fixture | PASS (E2) |
| NIBC-R005 | Purpose must be explicitly allowed | purpose allow-list | unit test | PASS (E2) |
| NIBC-R006 | Operation must be explicitly allowed | operation allow-list | unit test | PASS (E2) |
| NIBC-R007 | Destination must be explicitly allowed | destination allow-list | implementation + static review | PASS (E1) / E2 indirect |
| NIBC-R008 | Required external consent unknown → freeze | consent gate | unit + fixture | PASS (E2) |
| NIBC-R009 | Required external consent denied → deny | consent gate | unit test | PASS (E2) |
| NIBC-R010 | Required user authority unknown → freeze | user-authority gate | unit test | PASS (E2) |
| NIBC-R011 | Requested retention must be explicit for STORE | retention gate | unit test | PASS (E2) |
| NIBC-R012 | Over-retention must deny, not silently clip | retention gate | unit + fixture | PASS (E2) |
| NIBC-R013 | Valid retention adds expiry obligations | obligations | unit test | PASS (E2) |
| NIBC-R014 | Delete requires target identity | delete gate | unit test | PASS (E2) |
| NIBC-R015 | Delete requires explicit user authority | delete gate | unit + fixture | PASS (E2) |
| NIBC-R016 | Allowed delete emits proof obligations | deletion obligations | unit test | PASS (E2) |
| NIBC-R017 | Excess fields compile to explicit minimization transform | `DROP_FIELDS` | unit + fixture | PASS (E2) |
| NIBC-R018 | Required provenance missing/incomplete freezes | provenance gate | unit test | PASS (E2) |
| NIBC-R019 | Equal-priority contradictory rules freeze | rule resolver | unit test | PASS (E2) |
| NIBC-R020 | Higher-priority deny controls lower-priority allow | rule resolver | unit test | PASS (E2) |
| NIBC-R021 | Policy/request/decision contracts are machine-readable | JSON Schema files | validator | PASS (E1) |
| NIBC-R022 | Schema fixtures conform to Draft 2020-12 | `jsonschema` validator | `execution-evidence.json` | PASS (E1) |
| NIBC-R023 | Python sources parse | AST parse validation | validator | PASS (E1) |
| NIBC-R024 | Decision core has no hidden external I/O | source architecture + static inspection | source review; no runtime sandbox proof | PARTIAL (E1) |
| NIBC-R025 | No NEXY.AI repo mutation | mutation scope control | GitHub write audit/read-back required after publication | NOT_VERIFIED until repository publication audit |
| NIBC-R026 | Production enforces decision before every real disclosure | not implemented | requires NEXY integration/E3-E5 | NOT_VERIFIED |
| NIBC-R027 | Deletion actually removes all copies | obligations only | requires storage/provider integration | NOT_VERIFIED |
| NIBC-R028 | Policy is legally compliant in target jurisdiction | explicitly out of prototype scope | legal/privacy review required | NOT_VERIFIED |
