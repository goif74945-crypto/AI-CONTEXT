# 09 — Validation Report

Status: **PASS for the standalone reference prototype at E1/E2 only**

## Environment

- Python: `3.13.5`
- jsonschema: `4.26.0`
- coverage: `7.13.3`
- Network access required by decision core: no
- NEXY.AI runtime used: no

## Executed checks

| Check | Evidence class | Result |
|---|---:|---|
| JSON files parse | E1 | PASS |
| Draft 2020-12 schemas themselves validate | E1 | PASS |
| fixture policy validates | E1 | PASS |
| scenario requests validate | E1 | PASS (6 scenarios) |
| emitted decisions validate | E1 | PASS (6 decisions) |
| Python AST parse | E1 | PASS |
| unit/adversarial tests | E2 | PASS — Ran 41 tests in 0.004s |
| branch coverage gate | test-reachability metric | PASS — src/nibc.py 99.451% >= 98.0% |

Coverage is recorded only as reachability evidence. It is **not** treated as proof of correctness or production safety.

## Critical content SHA-256

These hashes bind the tested evidence to the critical source/test/schema/fixture inputs used by the validator.

| Path | SHA-256 |
|---|---|
| `src/nibc.py` | `cf31f785f1a4a3c9946c82dedf0a6d4543eb8c1b5741a7411420bbf3ff4f116d` |
| `tests/test_nibc.py` | `545b4203cb85f976a0858ba36abb37e404442bae9120208ae0530576fec8629b` |
| `fixtures/base_policy.json` | `57eafd503d29a1ec664dedc912fc1458701babb5ce126060ef1130c9f9a8ce30` |
| `fixtures/scenarios.json` | `82b309b0cb2c65ef4c476f03fc8b60ff80002663a94ec693cc1f1ea092771404` |
| `schemas/policy.schema.json` | `1365e2d6806d246b395b6fc18c838a5192e9371ebec3a0eca4120f9456670e4b` |
| `schemas/request.schema.json` | `eb301b3805ecd0c8fb0da2a0eaac2909238b29e9b34561a3a05e3e063c44da11` |
| `schemas/decision.schema.json` | `987bfec67783bf5031b971f45af02cfb961f7f6c52e7fc5ef2d1e0ff41621c91` |
| `requirements-dev.txt` | `dff1fb5e0de7d75d9821f8b04ed486b2e2b7470b488536bf88d558880c4d75d9` |

## Behavior slices proven at E2

- deterministic repeatability for identical explicit inputs;
- unknown data class/destination/sensitivity fail closed;
- purpose/operation/destination restrictions deny;
- clearance overflow denies before consent can rescue it;
- consent unknown freezes and consent denial denies;
- explicit user-authority missing freezes and false denies where required;
- durable-store and retention checks;
- over-retention denies without silent clipping;
- deletion target/authority and deletion-proof obligations;
- field minimization transform generation;
- provenance missing/incomplete freeze;
- equal-priority rule conflict freeze;
- high-priority deny;
- invalid policy/request/rule contracts freeze;
- allow rules may add transforms/obligations but do not bypass mandatory gates.

## Not proven

- no integration with NEXY.AI code (E3);
- no browser/user journey (E4);
- no target runtime/operational behavior (E5);
- no deployment (E6);
- no legal/privacy compliance certification;
- no proof that any real storage provider deletes all copies;
- no semantic classifier correctness;
- no side-channel resistance.

## Raw evidence

See `execution-evidence.json`.
