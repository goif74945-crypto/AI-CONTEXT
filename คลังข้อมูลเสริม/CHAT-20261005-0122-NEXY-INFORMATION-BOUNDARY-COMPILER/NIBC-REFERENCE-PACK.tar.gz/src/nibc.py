from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, asdict
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple


OUTCOME_ALLOW = "ALLOW"
OUTCOME_DENY = "DENY"
OUTCOME_FREEZE = "FREEZE"

CONSENT_GRANTED = "GRANTED"
CONSENT_DENIED = "DENIED"
CONSENT_UNKNOWN = "UNKNOWN"
CONSENT_NOT_REQUIRED = "NOT_REQUIRED"


@dataclass(frozen=True)
class Decision:
    decision_id: str
    outcome: str
    reason_code: str
    transforms: Tuple[Mapping[str, Any], ...]
    obligations: Tuple[str, ...]
    trace: Tuple[Mapping[str, Any], ...]
    policy_id: str
    policy_version: str

    def to_dict(self) -> Dict[str, Any]:
        raw = asdict(self)
        raw["transforms"] = [dict(v) for v in self.transforms]
        raw["obligations"] = list(self.obligations)
        raw["trace"] = [dict(v) for v in self.trace]
        return raw


class PolicyError(ValueError):
    pass


class InformationBoundaryCompiler:
    """Deterministic, fail-closed reference compiler for information-flow decisions.

    This module intentionally performs no network, filesystem, clock, environment,
    randomness, or database access. Every decision is derived only from explicit
    policy + request inputs.
    """

    REQUIRED_POLICY_KEYS = {
        "policy_id",
        "version",
        "sensitivity_order",
        "data_classes",
        "destinations",
    }
    REQUIRED_REQUEST_KEYS = {
        "request_id",
        "data_class",
        "purpose",
        "operation",
        "destination",
        "field_names",
    }

    def compile(self, policy: Mapping[str, Any], request: Mapping[str, Any]) -> Decision:
        trace: List[Mapping[str, Any]] = []
        transforms: List[Mapping[str, Any]] = []
        obligations: List[str] = []

        try:
            self._validate_policy(policy)
            self._validate_request_shape(request)
        except PolicyError as exc:
            return self._decision(
                policy=policy,
                request=request,
                outcome=OUTCOME_FREEZE,
                reason_code="INVALID_CONTRACT",
                transforms=transforms,
                obligations=obligations,
                trace=[{"gate": "contract", "status": "FAIL", "detail": str(exc)}],
            )

        data_class_name = str(request["data_class"])
        destination_name = str(request["destination"])
        purpose = str(request["purpose"])
        operation = str(request["operation"]).upper()

        data_classes = policy["data_classes"]
        destinations = policy["destinations"]

        if data_class_name not in data_classes:
            return self._freeze(policy, request, "UNKNOWN_DATA_CLASS", trace, transforms, obligations)
        if destination_name not in destinations:
            return self._freeze(policy, request, "UNKNOWN_DESTINATION", trace, transforms, obligations)

        data_class = data_classes[data_class_name]
        destination = destinations[destination_name]
        trace.append({"gate": "identity", "status": "PASS"})

        sensitivity_order = list(policy["sensitivity_order"])
        source_sensitivity = data_class.get("sensitivity")
        destination_clearance = destination.get("max_sensitivity")
        if source_sensitivity not in sensitivity_order or destination_clearance not in sensitivity_order:
            return self._freeze(policy, request, "UNKNOWN_SENSITIVITY_LEVEL", trace, transforms, obligations)

        if sensitivity_order.index(source_sensitivity) > sensitivity_order.index(destination_clearance):
            trace.append({
                "gate": "clearance",
                "status": "FAIL",
                "source": source_sensitivity,
                "destination_max": destination_clearance,
            })
            return self._deny(policy, request, "DESTINATION_CLEARANCE_EXCEEDED", trace, transforms, obligations)
        trace.append({"gate": "clearance", "status": "PASS"})

        allowed_purposes = set(data_class.get("allowed_purposes", []))
        if purpose not in allowed_purposes:
            trace.append({"gate": "purpose", "status": "FAIL", "purpose": purpose})
            return self._deny(policy, request, "PURPOSE_NOT_ALLOWED", trace, transforms, obligations)
        trace.append({"gate": "purpose", "status": "PASS"})

        allowed_operations = {str(x).upper() for x in data_class.get("allowed_operations", [])}
        if operation not in allowed_operations:
            trace.append({"gate": "operation", "status": "FAIL", "operation": operation})
            return self._deny(policy, request, "OPERATION_NOT_ALLOWED", trace, transforms, obligations)
        trace.append({"gate": "operation", "status": "PASS"})

        allowed_destinations = set(data_class.get("allowed_destinations", []))
        if destination_name not in allowed_destinations:
            trace.append({"gate": "destination", "status": "FAIL", "destination": destination_name})
            return self._deny(policy, request, "DESTINATION_NOT_ALLOWED", trace, transforms, obligations)
        trace.append({"gate": "destination", "status": "PASS"})

        rule_outcome = self._evaluate_rules(policy.get("rules", []), request, trace, transforms, obligations)
        if rule_outcome is not None:
            return self._decision(
                policy, request, rule_outcome[0], rule_outcome[1], transforms, obligations, trace
            )

        external = bool(destination.get("external", False))
        consent_required = bool(data_class.get("consent_required_for_external", False)) and external
        if consent_required:
            consent_state = request.get("consent_state")
            if consent_state is None or consent_state == CONSENT_UNKNOWN:
                trace.append({"gate": "consent", "status": "UNKNOWN"})
                return self._freeze(policy, request, "CONSENT_STATE_UNKNOWN", trace, transforms, obligations)
            if consent_state == CONSENT_DENIED:
                trace.append({"gate": "consent", "status": "FAIL"})
                return self._deny(policy, request, "CONSENT_DENIED", trace, transforms, obligations)
            if consent_state != CONSENT_GRANTED:
                trace.append({"gate": "consent", "status": "FAIL", "value": consent_state})
                return self._freeze(policy, request, "INVALID_CONSENT_STATE", trace, transforms, obligations)
            trace.append({"gate": "consent", "status": "PASS"})
        else:
            trace.append({"gate": "consent", "status": "NOT_REQUIRED"})

        if external and bool(data_class.get("external_requires_user_authority", False)):
            user_auth = request.get("user_authorized")
            if user_auth is None:
                trace.append({"gate": "user_authority", "status": "UNKNOWN"})
                return self._freeze(policy, request, "USER_AUTHORITY_UNKNOWN", trace, transforms, obligations)
            if user_auth is not True:
                trace.append({"gate": "user_authority", "status": "FAIL"})
                return self._deny(policy, request, "USER_AUTHORITY_DENIED", trace, transforms, obligations)
            trace.append({"gate": "user_authority", "status": "PASS"})

        if operation == "STORE":
            if not bool(destination.get("durable", False)):
                trace.append({"gate": "storage", "status": "FAIL", "detail": "destination_not_durable"})
                return self._deny(policy, request, "DESTINATION_NOT_DURABLE", trace, transforms, obligations)
            if not bool(data_class.get("durable_storage_allowed", False)):
                trace.append({"gate": "storage", "status": "FAIL", "detail": "class_disallows_durable"})
                return self._deny(policy, request, "DURABLE_STORAGE_NOT_ALLOWED", trace, transforms, obligations)
            requested_retention = request.get("requested_retention_seconds")
            if requested_retention is None:
                trace.append({"gate": "retention", "status": "UNKNOWN"})
                return self._freeze(policy, request, "RETENTION_UNKNOWN", trace, transforms, obligations)
            if not isinstance(requested_retention, int) or requested_retention < 0:
                trace.append({"gate": "retention", "status": "FAIL", "value": requested_retention})
                return self._freeze(policy, request, "INVALID_RETENTION", trace, transforms, obligations)
            max_retention = data_class.get("max_retention_seconds")
            if not isinstance(max_retention, int) or max_retention < 0:
                trace.append({"gate": "retention_policy", "status": "FAIL"})
                return self._freeze(policy, request, "INVALID_RETENTION_POLICY", trace, transforms, obligations)
            if requested_retention > max_retention:
                trace.append({
                    "gate": "retention",
                    "status": "FAIL",
                    "requested": requested_retention,
                    "max": max_retention,
                })
                return self._deny(policy, request, "RETENTION_EXCEEDS_POLICY", trace, transforms, obligations)
            obligations.extend(["record_retention_deadline", "enforce_expiry"])
            trace.append({"gate": "retention", "status": "PASS", "requested": requested_retention})

        if operation == "DELETE":
            resource_id = request.get("resource_id")
            if not isinstance(resource_id, str) or not resource_id.strip():
                trace.append({"gate": "delete_target", "status": "UNKNOWN"})
                return self._freeze(policy, request, "DELETE_TARGET_UNKNOWN", trace, transforms, obligations)
            user_auth = request.get("user_authorized")
            if user_auth is None:
                trace.append({"gate": "delete_authority", "status": "UNKNOWN"})
                return self._freeze(policy, request, "DELETE_AUTHORITY_UNKNOWN", trace, transforms, obligations)
            if user_auth is not True:
                trace.append({"gate": "delete_authority", "status": "FAIL"})
                return self._deny(policy, request, "DELETE_AUTHORITY_DENIED", trace, transforms, obligations)
            obligations.extend(["emit_deletion_receipt", "verify_target_absence", "preserve_nonsecret_audit_lineage"])
            trace.append({"gate": "delete_contract", "status": "PASS"})

        allowed_fields_by_purpose = data_class.get("allowed_fields_by_purpose", {})
        allowed_fields = allowed_fields_by_purpose.get(purpose)
        if allowed_fields is not None:
            requested_fields = [str(v) for v in request.get("field_names", [])]
            excess = sorted(set(requested_fields) - set(allowed_fields))
            if excess:
                transforms.append({"type": "DROP_FIELDS", "fields": excess})
                trace.append({"gate": "minimization", "status": "TRANSFORM", "drop": excess})
            else:
                trace.append({"gate": "minimization", "status": "PASS"})
        else:
            trace.append({"gate": "minimization", "status": "NO_FIELD_POLICY"})

        required_provenance = bool(data_class.get("provenance_required", True))
        if required_provenance:
            provenance = request.get("provenance")
            if not isinstance(provenance, Mapping):
                trace.append({"gate": "provenance", "status": "UNKNOWN"})
                return self._freeze(policy, request, "PROVENANCE_MISSING", trace, transforms, obligations)
            for key in ("source_id", "origin"):
                if not isinstance(provenance.get(key), str) or not provenance.get(key, "").strip():
                    trace.append({"gate": "provenance", "status": "FAIL", "missing": key})
                    return self._freeze(policy, request, "PROVENANCE_INCOMPLETE", trace, transforms, obligations)
            trace.append({"gate": "provenance", "status": "PASS"})

        obligations.append("append_boundary_decision_audit_record")
        trace.append({"gate": "release", "status": "PASS"})
        return self._decision(
            policy, request, OUTCOME_ALLOW, "POLICY_SATISFIED", transforms, obligations, trace
        )

    def _evaluate_rules(
        self,
        rules: Sequence[Mapping[str, Any]],
        request: Mapping[str, Any],
        trace: List[Mapping[str, Any]],
        transforms: List[Mapping[str, Any]],
        obligations: List[str],
    ) -> Optional[Tuple[str, str]]:
        matched: List[Mapping[str, Any]] = []
        for rule in rules:
            when = rule.get("when", {})
            if all(request.get(k) == v for k, v in when.items()):
                matched.append(rule)

        if not matched:
            trace.append({"gate": "rules", "status": "NO_MATCH"})
            return None

        priorities: List[int] = []
        for rule in matched:
            p = rule.get("priority")
            if not isinstance(p, int):
                trace.append({"gate": "rules", "status": "FAIL", "detail": "non_integer_priority"})
                return OUTCOME_FREEZE, "INVALID_RULE_PRIORITY"
            priorities.append(p)

        highest = max(priorities)
        top = [r for r in matched if r.get("priority") == highest]
        effects = {str(r.get("effect", "")).upper() for r in top}
        if not effects <= {OUTCOME_ALLOW, OUTCOME_DENY}:
            trace.append({"gate": "rules", "status": "FAIL", "detail": "invalid_effect"})
            return OUTCOME_FREEZE, "INVALID_RULE_EFFECT"
        if len(effects) > 1:
            trace.append({
                "gate": "rules",
                "status": "CONFLICT",
                "priority": highest,
                "rule_ids": sorted(str(r.get("rule_id", "")) for r in top),
            })
            return OUTCOME_FREEZE, "EQUAL_AUTHORITY_RULE_CONFLICT"

        for rule in sorted(top, key=lambda r: str(r.get("rule_id", ""))):
            for transform in rule.get("transforms", []):
                if transform not in transforms:
                    transforms.append(transform)
            for obligation in rule.get("obligations", []):
                if obligation not in obligations:
                    obligations.append(str(obligation))

        effect = next(iter(effects))
        trace.append({
            "gate": "rules",
            "status": "PASS" if effect == OUTCOME_ALLOW else "FAIL",
            "priority": highest,
            "effect": effect,
        })
        if effect == OUTCOME_DENY:
            return OUTCOME_DENY, "EXPLICIT_RULE_DENY"
        return None

    def _validate_policy(self, policy: Mapping[str, Any]) -> None:
        if not isinstance(policy, Mapping):
            raise PolicyError("policy must be an object")
        missing = sorted(self.REQUIRED_POLICY_KEYS - set(policy.keys()))
        if missing:
            raise PolicyError(f"missing policy keys: {missing}")
        if not isinstance(policy.get("policy_id"), str) or not policy["policy_id"].strip():
            raise PolicyError("policy_id must be a non-empty string")
        if not isinstance(policy.get("version"), str) or not policy["version"].strip():
            raise PolicyError("version must be a non-empty string")
        order = policy.get("sensitivity_order")
        if not isinstance(order, list) or not order or len(set(order)) != len(order):
            raise PolicyError("sensitivity_order must be a non-empty unique list")
        if not all(isinstance(x, str) and x for x in order):
            raise PolicyError("sensitivity_order entries must be non-empty strings")
        if not isinstance(policy.get("data_classes"), Mapping):
            raise PolicyError("data_classes must be an object")
        if not isinstance(policy.get("destinations"), Mapping):
            raise PolicyError("destinations must be an object")
        if "rules" in policy and not isinstance(policy["rules"], list):
            raise PolicyError("rules must be an array")

    def _validate_request_shape(self, request: Mapping[str, Any]) -> None:
        if not isinstance(request, Mapping):
            raise PolicyError("request must be an object")
        missing = sorted(self.REQUIRED_REQUEST_KEYS - set(request.keys()))
        if missing:
            raise PolicyError(f"missing request keys: {missing}")
        if not isinstance(request.get("request_id"), str) or not request["request_id"].strip():
            raise PolicyError("request_id must be a non-empty string")
        if not isinstance(request.get("field_names"), list) or not all(
            isinstance(v, str) and v for v in request["field_names"]
        ):
            raise PolicyError("field_names must be an array of non-empty strings")

    def _deny(
        self,
        policy: Mapping[str, Any],
        request: Mapping[str, Any],
        reason: str,
        trace: List[Mapping[str, Any]],
        transforms: List[Mapping[str, Any]],
        obligations: List[str],
    ) -> Decision:
        return self._decision(policy, request, OUTCOME_DENY, reason, transforms, obligations, trace)

    def _freeze(
        self,
        policy: Mapping[str, Any],
        request: Mapping[str, Any],
        reason: str,
        trace: List[Mapping[str, Any]],
        transforms: List[Mapping[str, Any]],
        obligations: List[str],
    ) -> Decision:
        return self._decision(policy, request, OUTCOME_FREEZE, reason, transforms, obligations, trace)

    def _decision(
        self,
        policy: Mapping[str, Any],
        request: Mapping[str, Any],
        outcome: str,
        reason_code: str,
        transforms: Iterable[Mapping[str, Any]],
        obligations: Iterable[str],
        trace: Iterable[Mapping[str, Any]],
    ) -> Decision:
        policy_id = str(policy.get("policy_id", "UNKNOWN")) if isinstance(policy, Mapping) else "UNKNOWN"
        policy_version = str(policy.get("version", "UNKNOWN")) if isinstance(policy, Mapping) else "UNKNOWN"
        canonical = {
            "policy_id": policy_id,
            "policy_version": policy_version,
            "request": request,
            "outcome": outcome,
            "reason_code": reason_code,
            "transforms": list(transforms),
            "obligations": sorted(set(str(v) for v in obligations)),
        }
        material = json.dumps(canonical, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        decision_id = "nibc:" + hashlib.sha256(material.encode("utf-8")).hexdigest()
        return Decision(
            decision_id=decision_id,
            outcome=outcome,
            reason_code=reason_code,
            transforms=tuple(canonical["transforms"]),
            obligations=tuple(canonical["obligations"]),
            trace=tuple(trace),
            policy_id=policy_id,
            policy_version=policy_version,
        )


def compile_decision(policy: Mapping[str, Any], request: Mapping[str, Any]) -> Dict[str, Any]:
    return InformationBoundaryCompiler().compile(policy, request).to_dict()
