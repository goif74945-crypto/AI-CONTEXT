# 05 — Threat and Failure Model

Status: AI_PROPOSED_THREAT_MODEL

## Threat classes

| ID | Threat / failure | Reference response | Residual gap |
|---|---|---|---|
| T01 | restricted data sent to low-clearance destination | DENY | correctness of classification is external |
| T02 | request purpose drifts from allowed purpose | DENY | semantic purpose classification is external |
| T03 | external model receives data without required consent | FREEZE/DENY | consent capture UX/integrity external |
| T04 | user authority omitted or forged by adapter | FREEZE for missing; adapter authentication external | caller authenticity not proven by compiler |
| T05 | retention silently grows | DENY | storage expiry enforcement external |
| T06 | field overcollection | compile `DROP_FIELDS` transform | transform execution external |
| T07 | equal-authority rules conflict | FREEZE | policy governance must resolve conflict |
| T08 | lower-priority allow attempts to bypass deny | highest priority wins | priority governance external |
| T09 | raw data arrives without provenance | FREEZE | provenance authenticity external |
| T10 | delete request lacks exact target | FREEZE | storage graph completeness external |
| T11 | system claims deletion without proof | proof obligations required | actual deletion proof not implemented |
| T12 | stale policy version used | decision records version | freshness/admission service external |
| T13 | prompt injection asks agent to ignore boundary | model output has no policy authority | executor must actually call/enforce NIBC |
| T14 | destination characteristics change after policy admission | versioned destination policy required | live capability attestation external |
| T15 | shadow copies/logs preserve deleted data | not solved by reference compiler | requires system-wide data inventory |
| T16 | sensitive meaning leaks through apparently safe fields | not solved by field-name minimization | semantic leakage research required |
| T17 | timing/error side-channel leaks sensitive existence | not modeled | runtime/E5 testing required |
| T18 | policy itself is malicious or overpermissive | compiler follows admitted policy | policy authority/admission independent |
| T19 | consent granted for one purpose reused for another | purpose remains independently enforced | consent provenance/versioning future work |
| T20 | external provider retains input unexpectedly | destination policy can deny/limit | provider contract/runtime proof external |

## Failure classes

### Contract failure
Malformed or incomplete policy/request → `FREEZE`.

### Identity failure
Unknown data class/destination/sensitivity → `FREEZE`.

### Explicit prohibition
Clearance/purpose/operation/destination/consent/authority/retention prohibition → `DENY`.

### Authority conflict
Equal-priority allow/deny collision → `FREEZE`.

### Enforcement gap
Compiler says ALLOW with obligations but executor fails to apply transform/expiry/delete proof. This is outside E2 prototype proof and must be treated as integration failure, not compiler PASS.

## Security invariant

An instruction inside user content, model output, tool result, document, or webpage cannot alter NIBC policy simply by being present in the data. Policy mutation requires a separate authorized governance path.

## Logging guidance

Future audit logs should prefer:
- decision ID;
- request ID;
- policy ID/version;
- data-class identifier;
- destination identifier;
- outcome/reason;
- obligation completion references.

Avoid logging raw protected payload unless an explicit authorized evidence requirement demands it.
