# 04 — Policy / Request / Decision Contract

Status: AI_PROPOSED_CONTRACT

## 1. Truth boundary

This contract is an R&D proposal. It does not override NEXY project law or current build authority.

## 2. Policy object

Required top-level fields:

```json
{
  "policy_id": "...",
  "version": "...",
  "sensitivity_order": ["PUBLIC", "INTERNAL", "CONFIDENTIAL", "RESTRICTED"],
  "data_classes": {},
  "destinations": {},
  "rules": []
}
```

### Sensitivity order

The array is low → high. The compiler does not invent a universal sensitivity taxonomy; the governing policy provides it.

A destination may receive a data class only when:

```text
rank(data.sensitivity) <= rank(destination.max_sensitivity)
```

Unknown levels freeze.

### Data-class fields

- `sensitivity`
- `allowed_purposes[]`
- `allowed_operations[]`
- `allowed_destinations[]`
- `consent_required_for_external`
- `external_requires_user_authority`
- `durable_storage_allowed`
- `max_retention_seconds`
- `provenance_required`
- `allowed_fields_by_purpose{purpose:[fields...]}`

### Destination fields

- `max_sensitivity`
- `external`
- `durable`

## 3. Rule semantics

Each rule has:
- stable `rule_id`;
- integer `priority`;
- exact-match `when` object;
- `effect` of `ALLOW` or `DENY`;
- optional transforms;
- optional obligations.

Resolution:
1. find matching rules;
2. choose highest numeric priority;
3. if highest-priority rules disagree on effect → `FREEZE/EQUAL_AUTHORITY_RULE_CONFLICT`;
4. if they agree on `DENY` → deny;
5. if they agree on `ALLOW` → merge declared transforms/obligations and continue mandatory gates.

This avoids making an `ALLOW` rule a blanket bypass token.

## 4. Request object

Material fields:
- `request_id`
- `data_class`
- `purpose`
- `operation`
- `destination`
- `field_names[]`

Conditional fields:
- `consent_state`
- `user_authorized`
- `requested_retention_seconds`
- `resource_id`
- `provenance.source_id`
- `provenance.origin`

The reference schema currently permits additional request metadata for future adapters, but the compiler ignores unknown keys unless promoted into explicit semantics.

## 5. Consent semantics

Configured external disclosure may require:
- `GRANTED` → continue;
- `DENIED` → deny;
- `UNKNOWN` or missing → freeze;
- any unrecognized state → freeze.

Consent is not equivalent to security clearance and does not override a clearance denial.

## 6. User authority semantics

Where configured, external disclosure requires `user_authorized=true`.

- missing → freeze;
- false → deny;
- true → continue, still subject to every other gate.

Delete operations independently require explicit user authority in the reference implementation.

## 7. Retention semantics

For `STORE`:
- destination must be durable;
- data class must allow durable storage;
- requested retention must be explicit and non-negative;
- request must not exceed policy max.

The compiler intentionally does not silently reduce an overlong retention request because that would change request semantics without authority.

## 8. Minimization semantics

If the selected purpose has a field allow-list, every requested field outside it becomes an explicit transform:

```json
{"type":"DROP_FIELDS","fields":["..."]}
```

A future executor must apply and verify this transform before disclosure. The reference compiler plans the transform; it does not manipulate raw payload values.

## 9. Deletion semantics

Allowed deletion requires:
- known resource ID;
- explicit user authority;
- all normal policy gates.

It emits obligations:
- `emit_deletion_receipt`
- `verify_target_absence`
- `preserve_nonsecret_audit_lineage`

These obligations are not proof that deletion occurred. They define what a production adapter would need to prove.

## 10. Decision identity

`decision_id` is SHA-256 over canonicalized:
- policy identity/version;
- request object;
- outcome/reason;
- transforms;
- obligations.

No clock/random nonce is used. This makes identical explicit inputs structurally reproducible.
