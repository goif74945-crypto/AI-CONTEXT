import copy
import json
import pathlib
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from nibc import InformationBoundaryCompiler  # noqa: E402


class NIBCTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.policy = json.loads((ROOT / "fixtures" / "base_policy.json").read_text(encoding="utf-8"))
        cls.compiler = InformationBoundaryCompiler()

    def req(self, **overrides):
        base = {
            "request_id": "req-default",
            "data_class": "public_reference",
            "purpose": "answer",
            "operation": "READ",
            "destination": "local_core",
            "field_names": ["title", "body"],
            "provenance": {"source_id": "doc:1", "origin": "unit_test"},
        }
        base.update(overrides)
        return base

    def test_public_local_allow(self):
        d = self.compiler.compile(self.policy, self.req())
        self.assertEqual("ALLOW", d.outcome)
        self.assertEqual("POLICY_SATISFIED", d.reason_code)

    def test_unknown_data_class_freezes(self):
        d = self.compiler.compile(self.policy, self.req(data_class="missing"))
        self.assertEqual(("FREEZE", "UNKNOWN_DATA_CLASS"), (d.outcome, d.reason_code))

    def test_unknown_destination_freezes(self):
        d = self.compiler.compile(self.policy, self.req(destination="missing"))
        self.assertEqual(("FREEZE", "UNKNOWN_DESTINATION"), (d.outcome, d.reason_code))

    def test_purpose_mismatch_denies(self):
        d = self.compiler.compile(self.policy, self.req(purpose="marketing"))
        self.assertEqual(("DENY", "PURPOSE_NOT_ALLOWED"), (d.outcome, d.reason_code))

    def test_operation_mismatch_denies(self):
        d = self.compiler.compile(self.policy, self.req(operation="STORE"))
        self.assertEqual(("DENY", "OPERATION_NOT_ALLOWED"), (d.outcome, d.reason_code))

    def test_destination_clearance_denies_before_consent(self):
        d = self.compiler.compile(
            self.policy,
            self.req(
                data_class="user_private",
                purpose="personal_assistance",
                destination="external_model",
                field_names=["preference"],
                consent_state="GRANTED",
                user_authorized=True,
            ),
        )
        self.assertEqual(("DENY", "DESTINATION_CLEARANCE_EXCEEDED"), (d.outcome, d.reason_code))

    def test_external_consent_unknown_freezes(self):
        d = self.compiler.compile(
            self.policy,
            self.req(
                data_class="user_shareable",
                purpose="personal_assistance",
                destination="external_model",
                field_names=["preference"],
                consent_state="UNKNOWN",
                user_authorized=True,
            ),
        )
        self.assertEqual(("FREEZE", "CONSENT_STATE_UNKNOWN"), (d.outcome, d.reason_code))

    def test_external_consent_denied_denies(self):
        d = self.compiler.compile(
            self.policy,
            self.req(
                data_class="user_shareable",
                purpose="personal_assistance",
                destination="external_model",
                field_names=["preference"],
                consent_state="DENIED",
                user_authorized=True,
            ),
        )
        self.assertEqual(("DENY", "CONSENT_DENIED"), (d.outcome, d.reason_code))

    def test_external_user_authority_unknown_freezes(self):
        d = self.compiler.compile(
            self.policy,
            self.req(
                data_class="user_shareable",
                purpose="personal_assistance",
                destination="external_model",
                field_names=["preference"],
                consent_state="GRANTED",
            ),
        )
        self.assertEqual(("FREEZE", "USER_AUTHORITY_UNKNOWN"), (d.outcome, d.reason_code))

    def test_minimization_emits_drop_fields(self):
        d = self.compiler.compile(
            self.policy,
            self.req(
                data_class="user_shareable",
                purpose="personal_assistance",
                destination="external_model",
                field_names=["preference", "locale", "irrelevant_note"],
                consent_state="GRANTED",
                user_authorized=True,
            ),
        )
        self.assertEqual("ALLOW", d.outcome)
        self.assertIn({"type": "DROP_FIELDS", "fields": ["irrelevant_note"]}, list(d.transforms))

    def test_store_requires_retention(self):
        d = self.compiler.compile(
            self.policy,
            self.req(
                data_class="user_private",
                purpose="personal_assistance",
                operation="STORE",
                destination="vault_private",
                field_names=["preference"],
            ),
        )
        self.assertEqual(("FREEZE", "RETENTION_UNKNOWN"), (d.outcome, d.reason_code))

    def test_retention_excess_denies_without_clipping(self):
        d = self.compiler.compile(
            self.policy,
            self.req(
                data_class="user_private",
                purpose="personal_assistance",
                operation="STORE",
                destination="vault_private",
                field_names=["preference"],
                requested_retention_seconds=2592001,
            ),
        )
        self.assertEqual(("DENY", "RETENTION_EXCEEDS_POLICY"), (d.outcome, d.reason_code))

    def test_valid_store_adds_retention_obligations(self):
        d = self.compiler.compile(
            self.policy,
            self.req(
                data_class="user_private",
                purpose="personal_assistance",
                operation="STORE",
                destination="vault_private",
                field_names=["preference"],
                requested_retention_seconds=3600,
            ),
        )
        self.assertEqual("ALLOW", d.outcome)
        self.assertIn("record_retention_deadline", d.obligations)
        self.assertIn("enforce_expiry", d.obligations)

    def test_delete_requires_target(self):
        d = self.compiler.compile(
            self.policy,
            self.req(
                data_class="user_private",
                purpose="delete",
                operation="DELETE",
                destination="vault_private",
                field_names=["resource_id"],
                user_authorized=True,
            ),
        )
        self.assertEqual(("FREEZE", "DELETE_TARGET_UNKNOWN"), (d.outcome, d.reason_code))

    def test_delete_requires_explicit_authority(self):
        d = self.compiler.compile(
            self.policy,
            self.req(
                data_class="user_private",
                purpose="delete",
                operation="DELETE",
                destination="vault_private",
                field_names=["resource_id"],
                resource_id="vault:123",
            ),
        )
        self.assertEqual(("FREEZE", "DELETE_AUTHORITY_UNKNOWN"), (d.outcome, d.reason_code))

    def test_delete_contract_emits_proof_obligations(self):
        d = self.compiler.compile(
            self.policy,
            self.req(
                data_class="user_private",
                purpose="delete",
                operation="DELETE",
                destination="vault_private",
                field_names=["resource_id"],
                resource_id="vault:123",
                user_authorized=True,
            ),
        )
        self.assertEqual("ALLOW", d.outcome)
        self.assertIn("emit_deletion_receipt", d.obligations)
        self.assertIn("verify_target_absence", d.obligations)

    def test_missing_provenance_freezes(self):
        req = self.req()
        req.pop("provenance")
        d = self.compiler.compile(self.policy, req)
        self.assertEqual(("FREEZE", "PROVENANCE_MISSING"), (d.outcome, d.reason_code))

    def test_equal_priority_conflicting_rules_freeze(self):
        policy = copy.deepcopy(self.policy)
        policy["rules"] = [
            {"rule_id": "a", "priority": 50, "when": {"purpose": "answer"}, "effect": "ALLOW"},
            {"rule_id": "b", "priority": 50, "when": {"purpose": "answer"}, "effect": "DENY"},
        ]
        d = self.compiler.compile(policy, self.req())
        self.assertEqual(("FREEZE", "EQUAL_AUTHORITY_RULE_CONFLICT"), (d.outcome, d.reason_code))

    def test_higher_priority_deny_wins(self):
        policy = copy.deepcopy(self.policy)
        policy["rules"] = [
            {"rule_id": "low_allow", "priority": 10, "when": {"purpose": "answer"}, "effect": "ALLOW"},
            {"rule_id": "high_deny", "priority": 20, "when": {"purpose": "answer"}, "effect": "DENY"},
        ]
        d = self.compiler.compile(policy, self.req())
        self.assertEqual(("DENY", "EXPLICIT_RULE_DENY"), (d.outcome, d.reason_code))

    def test_deterministic_decision_id(self):
        req = self.req()
        a = self.compiler.compile(self.policy, req)
        b = self.compiler.compile(self.policy, copy.deepcopy(req))
        self.assertEqual(a.decision_id, b.decision_id)
        self.assertEqual(a.to_dict(), b.to_dict())

    def test_invalid_policy_contract_freezes(self):
        policy = {"policy_id": "x"}
        d = self.compiler.compile(policy, self.req())
        self.assertEqual(("FREEZE", "INVALID_CONTRACT"), (d.outcome, d.reason_code))

    def test_fixture_corpus(self):
        scenarios = json.loads((ROOT / "fixtures" / "scenarios.json").read_text(encoding="utf-8"))
        for scenario in scenarios:
            with self.subTest(scenario=scenario["name"]):
                d = self.compiler.compile(self.policy, scenario["request"])
                self.assertEqual(tuple(scenario["expected"]), (d.outcome, d.reason_code))


    def test_unknown_source_sensitivity_freezes(self):
        policy = copy.deepcopy(self.policy)
        policy["data_classes"]["public_reference"]["sensitivity"] = "UNDEFINED"
        d = self.compiler.compile(policy, self.req())
        self.assertEqual(("FREEZE", "UNKNOWN_SENSITIVITY_LEVEL"), (d.outcome, d.reason_code))

    def test_destination_not_allowed_denies(self):
        policy = copy.deepcopy(self.policy)
        policy["data_classes"]["public_reference"]["allowed_destinations"] = ["external_model"]
        d = self.compiler.compile(policy, self.req(destination="local_core"))
        self.assertEqual(("DENY", "DESTINATION_NOT_ALLOWED"), (d.outcome, d.reason_code))

    def test_invalid_consent_state_freezes(self):
        d = self.compiler.compile(
            self.policy,
            self.req(
                data_class="user_shareable",
                purpose="personal_assistance",
                destination="external_model",
                field_names=["preference"],
                consent_state="MAYBE",
                user_authorized=True,
            ),
        )
        self.assertEqual(("FREEZE", "INVALID_CONSENT_STATE"), (d.outcome, d.reason_code))

    def test_external_user_authority_false_denies(self):
        d = self.compiler.compile(
            self.policy,
            self.req(
                data_class="user_shareable",
                purpose="personal_assistance",
                destination="external_model",
                field_names=["preference"],
                consent_state="GRANTED",
                user_authorized=False,
            ),
        )
        self.assertEqual(("DENY", "USER_AUTHORITY_DENIED"), (d.outcome, d.reason_code))

    def test_store_to_nondurable_destination_denies(self):
        policy = copy.deepcopy(self.policy)
        dc = policy["data_classes"]["public_reference"]
        dc["allowed_operations"] = ["READ", "STORE"]
        dc["durable_storage_allowed"] = True
        dc["max_retention_seconds"] = 100
        d = self.compiler.compile(
            policy,
            self.req(operation="STORE", requested_retention_seconds=10),
        )
        self.assertEqual(("DENY", "DESTINATION_NOT_DURABLE"), (d.outcome, d.reason_code))

    def test_data_class_disallows_durable_storage(self):
        policy = copy.deepcopy(self.policy)
        policy["data_classes"]["user_private"]["durable_storage_allowed"] = False
        d = self.compiler.compile(
            policy,
            self.req(
                data_class="user_private",
                purpose="personal_assistance",
                operation="STORE",
                destination="vault_private",
                field_names=["preference"],
                requested_retention_seconds=10,
            ),
        )
        self.assertEqual(("DENY", "DURABLE_STORAGE_NOT_ALLOWED"), (d.outcome, d.reason_code))

    def test_invalid_retention_freezes(self):
        d = self.compiler.compile(
            self.policy,
            self.req(
                data_class="user_private",
                purpose="personal_assistance",
                operation="STORE",
                destination="vault_private",
                field_names=["preference"],
                requested_retention_seconds=-1,
            ),
        )
        self.assertEqual(("FREEZE", "INVALID_RETENTION"), (d.outcome, d.reason_code))

    def test_invalid_retention_policy_freezes(self):
        policy = copy.deepcopy(self.policy)
        policy["data_classes"]["user_private"]["max_retention_seconds"] = -1
        d = self.compiler.compile(
            policy,
            self.req(
                data_class="user_private",
                purpose="personal_assistance",
                operation="STORE",
                destination="vault_private",
                field_names=["preference"],
                requested_retention_seconds=1,
            ),
        )
        self.assertEqual(("FREEZE", "INVALID_RETENTION_POLICY"), (d.outcome, d.reason_code))

    def test_delete_authority_false_denies(self):
        d = self.compiler.compile(
            self.policy,
            self.req(
                data_class="user_private",
                purpose="delete",
                operation="DELETE",
                destination="vault_private",
                field_names=["resource_id"],
                resource_id="vault:123",
                user_authorized=False,
            ),
        )
        self.assertEqual(("DENY", "DELETE_AUTHORITY_DENIED"), (d.outcome, d.reason_code))

    def test_no_field_policy_still_allows(self):
        policy = copy.deepcopy(self.policy)
        policy["data_classes"]["public_reference"].pop("allowed_fields_by_purpose")
        d = self.compiler.compile(policy, self.req())
        self.assertEqual("ALLOW", d.outcome)
        self.assertTrue(any(t.get("status") == "NO_FIELD_POLICY" for t in d.trace if t.get("gate") == "minimization"))

    def test_incomplete_provenance_freezes(self):
        d = self.compiler.compile(
            self.policy,
            self.req(provenance={"source_id": "doc:1", "origin": ""}),
        )
        self.assertEqual(("FREEZE", "PROVENANCE_INCOMPLETE"), (d.outcome, d.reason_code))

    def test_provenance_can_be_optional_by_policy(self):
        policy = copy.deepcopy(self.policy)
        policy["data_classes"]["public_reference"]["provenance_required"] = False
        req = self.req()
        req.pop("provenance")
        d = self.compiler.compile(policy, req)
        self.assertEqual("ALLOW", d.outcome)

    def test_allow_rule_adds_transform_and_obligation_without_bypass(self):
        policy = copy.deepcopy(self.policy)
        policy["rules"] = [{
            "rule_id": "decorate",
            "priority": 10,
            "when": {"purpose": "answer"},
            "effect": "ALLOW",
            "transforms": [{"type": "MARK", "value": "reviewed"}],
            "obligations": ["record_rule_match"],
        }]
        d = self.compiler.compile(policy, self.req())
        self.assertEqual("ALLOW", d.outcome)
        self.assertIn({"type": "MARK", "value": "reviewed"}, list(d.transforms))
        self.assertIn("record_rule_match", d.obligations)

    def test_invalid_rule_priority_freezes(self):
        policy = copy.deepcopy(self.policy)
        policy["rules"] = [{"rule_id": "x", "priority": "high", "when": {"purpose": "answer"}, "effect": "ALLOW"}]
        d = self.compiler.compile(policy, self.req())
        self.assertEqual(("FREEZE", "INVALID_RULE_PRIORITY"), (d.outcome, d.reason_code))

    def test_invalid_rule_effect_freezes(self):
        policy = copy.deepcopy(self.policy)
        policy["rules"] = [{"rule_id": "x", "priority": 1, "when": {"purpose": "answer"}, "effect": "MAGIC"}]
        d = self.compiler.compile(policy, self.req())
        self.assertEqual(("FREEZE", "INVALID_RULE_EFFECT"), (d.outcome, d.reason_code))

    def test_invalid_policy_variants_freeze(self):
        variants = [
            None,
            {**copy.deepcopy(self.policy), "policy_id": ""},
            {**copy.deepcopy(self.policy), "version": ""},
            {**copy.deepcopy(self.policy), "sensitivity_order": ["PUBLIC", "PUBLIC"]},
            {**copy.deepcopy(self.policy), "sensitivity_order": ["PUBLIC", ""]},
            {**copy.deepcopy(self.policy), "data_classes": []},
            {**copy.deepcopy(self.policy), "destinations": []},
            {**copy.deepcopy(self.policy), "rules": {}},
        ]
        for idx, policy in enumerate(variants):
            with self.subTest(idx=idx):
                d = self.compiler.compile(policy, self.req())
                self.assertEqual(("FREEZE", "INVALID_CONTRACT"), (d.outcome, d.reason_code))

    def test_invalid_request_variants_freeze(self):
        missing = self.req()
        missing.pop("purpose")
        variants = [
            None,
            missing,
            self.req(request_id=""),
            self.req(field_names="not-a-list"),
            self.req(field_names=["ok", ""]),
        ]
        for idx, req in enumerate(variants):
            with self.subTest(idx=idx):
                d = self.compiler.compile(self.policy, req)
                self.assertEqual(("FREEZE", "INVALID_CONTRACT"), (d.outcome, d.reason_code))

    def test_decision_id_changes_when_material_request_changes(self):
        a = self.compiler.compile(self.policy, self.req(request_id="a"))
        b = self.compiler.compile(self.policy, self.req(request_id="b"))
        self.assertNotEqual(a.decision_id, b.decision_id)

    def test_compile_decision_helper(self):
        from nibc import compile_decision
        d = compile_decision(self.policy, self.req())
        self.assertIsInstance(d, dict)
        self.assertEqual("ALLOW", d["outcome"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
