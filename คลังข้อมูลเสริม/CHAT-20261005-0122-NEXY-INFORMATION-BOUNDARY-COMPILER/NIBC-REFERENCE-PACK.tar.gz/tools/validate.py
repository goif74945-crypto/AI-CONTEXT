from __future__ import annotations

import ast
import importlib.metadata
import hashlib
import json
import pathlib
import subprocess
import sys
from typing import Any, Dict

from jsonschema import Draft202012Validator

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from nibc import InformationBoundaryCompiler  # noqa: E402


def load_json(path: pathlib.Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def check_json_parse() -> Dict[str, Any]:
    checked = []
    for path in sorted(list((ROOT / "fixtures").glob("*.json")) + list((ROOT / "schemas").glob("*.json"))):
        load_json(path)
        checked.append(str(path.relative_to(ROOT)))
    return {"status": "PASS", "checked": checked}


def check_json_schema() -> Dict[str, Any]:
    schemas = {
        "policy": load_json(ROOT / "schemas" / "policy.schema.json"),
        "request": load_json(ROOT / "schemas" / "request.schema.json"),
        "decision": load_json(ROOT / "schemas" / "decision.schema.json"),
    }
    for schema in schemas.values():
        Draft202012Validator.check_schema(schema)

    policy = load_json(ROOT / "fixtures" / "base_policy.json")
    Draft202012Validator(schemas["policy"]).validate(policy)

    compiler = InformationBoundaryCompiler()
    scenarios = load_json(ROOT / "fixtures" / "scenarios.json")
    checked_requests = []
    checked_decisions = []
    for scenario in scenarios:
        Draft202012Validator(schemas["request"]).validate(scenario["request"])
        checked_requests.append(scenario["name"])
        decision = compiler.compile(policy, scenario["request"]).to_dict()
        Draft202012Validator(schemas["decision"]).validate(decision)
        checked_decisions.append(scenario["name"])

    return {
        "status": "PASS",
        "schemas_checked": sorted(schemas.keys()),
        "fixture_policy_validated": True,
        "requests_validated": checked_requests,
        "decisions_validated": checked_decisions,
    }


def check_python_syntax() -> Dict[str, Any]:
    checked = []
    paths = list((ROOT / "src").glob("*.py")) + list((ROOT / "tests").glob("*.py")) + [ROOT / "tools" / "validate.py"]
    for path in sorted(paths):
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        checked.append(str(path.relative_to(ROOT)))
    return {"status": "PASS", "checked": checked}


def run_tests() -> Dict[str, Any]:
    proc = subprocess.run(
        [sys.executable, "-m", "unittest", "discover", "-s", str(ROOT / "tests"), "-p", "test_*.py", "-v"],
        cwd=ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    return {
        "status": "PASS" if proc.returncode == 0 else "FAIL",
        "returncode": proc.returncode,
        "output": proc.stdout,
    }


def run_branch_coverage() -> Dict[str, Any]:
    data_file = ROOT / ".coverage-nibc"
    json_file = ROOT / ".coverage-nibc.json"
    env = dict(__import__("os").environ)
    env["COVERAGE_FILE"] = str(data_file)
    run = subprocess.run(
        [sys.executable, "-m", "coverage", "run", "--branch", "--source", "src", "-m", "unittest", "discover", "-s", str(ROOT / "tests"), "-p", "test_*.py"],
        cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False, env=env
    )
    if run.returncode != 0:
        return {"status": "FAIL", "returncode": run.returncode, "output": run.stdout}
    emit = subprocess.run(
        [sys.executable, "-m", "coverage", "json", "-o", str(json_file)],
        cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False, env=env
    )
    if emit.returncode != 0:
        return {"status": "FAIL", "returncode": emit.returncode, "output": emit.stdout}
    report = json.loads(json_file.read_text(encoding="utf-8"))
    total = float(report["totals"]["percent_covered"])
    src_file = next((v for k, v in report["files"].items() if k.replace("\\", "/").endswith("src/nibc.py")), None)
    src_percent = float(src_file["summary"]["percent_covered"]) if src_file else total
    for path in (data_file, json_file):
        try:
            path.unlink()
        except FileNotFoundError:
            pass
    threshold = 98.0
    return {
        "status": "PASS" if src_percent >= threshold else "FAIL",
        "threshold_percent": threshold,
        "src_nibc_percent": round(src_percent, 3),
        "total_percent": round(total, 3),
        "note": "Coverage is a test reachability metric, not proof of correctness."
    }


def critical_hashes() -> Dict[str, str]:
    rels = [
        "src/nibc.py",
        "tests/test_nibc.py",
        "fixtures/base_policy.json",
        "fixtures/scenarios.json",
        "schemas/policy.schema.json",
        "schemas/request.schema.json",
        "schemas/decision.schema.json",
        "requirements-dev.txt",
    ]
    out: Dict[str, str] = {}
    for rel in rels:
        data = (ROOT / rel).read_bytes()
        out[rel] = hashlib.sha256(data).hexdigest()
    return out


def main() -> int:
    report: Dict[str, Any] = {
        "validator": "NIBC local deterministic validator",
        "evidence_scope": "reference prototype only; not NEXY.AI runtime",
        "environment": {
            "python": sys.version.split()[0],
            "jsonschema": importlib.metadata.version("jsonschema"),
            "coverage": importlib.metadata.version("coverage"),
        },
        "critical_content_sha256": critical_hashes(),
    }
    checks = {
        "json_parse": check_json_parse,
        "json_schema": check_json_schema,
        "python_syntax": check_python_syntax,
        "unit_tests": run_tests,
        "branch_coverage": run_branch_coverage,
    }

    overall = "PASS"
    for name, fn in checks.items():
        try:
            result = fn()
        except Exception as exc:  # validator must emit failure evidence rather than crash silently
            result = {"status": "FAIL", "error": f"{type(exc).__name__}: {exc}"}
        report[name] = result
        if result.get("status") != "PASS":
            overall = "FAIL"

    report["overall"] = overall
    output_path = ROOT / "execution-evidence.json"
    output_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if overall == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
