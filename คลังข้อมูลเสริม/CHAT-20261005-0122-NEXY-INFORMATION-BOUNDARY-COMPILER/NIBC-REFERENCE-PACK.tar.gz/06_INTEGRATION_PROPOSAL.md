# 06 — Non-Governing Integration Proposal

Status: AI_PROPOSED / NOT_IMPLEMENTED / NOT_CANONICAL

## Goal

Show how NIBC *could* integrate into NEXY without claiming that it already does.

## Proposed boundaries

### A. Context/agent disclosure gate
Before selected context is sent to an external AI/model/tool:

```text
context candidates
 -> normalize data classes + purposes
 -> NIBC compile
 -> DENY/FREEZE or apply minimization
 -> verify transforms
 -> disclose minimum allowed context
```

### B. Durable memory/vault gate
Before task/session material becomes durable:

```text
candidate memory
 -> classify + provenance bind
 -> purpose = memory_commit
 -> NIBC compile(STORE)
 -> retention obligation
 -> durable write
 -> expiry scheduler / audit receipt
```

### C. Export/share gate
Before files/results leave the trusted boundary:

```text
export intent
 -> enumerate data classes
 -> compile per flow / aggregate strictest decision
 -> require explicit authority where configured
 -> redact/minimize
 -> verify transformed artifact
 -> export
```

### D. Delete/forget gate

```text
user delete intent
 -> resolve exact resource graph
 -> compile DELETE
 -> execute deletion adapters
 -> verify absence per store/provider
 -> emit deletion receipt
 -> retain only nonsecret audit lineage allowed by policy
```

## Proposed adapter contract

A future adapter should provide:
- immutable policy identity/version;
- normalized request;
- authenticated user-authority signal;
- destination capability identity;
- transform executor;
- obligation executor;
- evidence sink.

## Aggregate decision rule

For a multi-item payload, a safe initial proposal is:

```text
if any item FREEZE -> aggregate FREEZE
else if any item DENY -> aggregate DENY
else -> ALLOW with union of required transforms/obligations
```

This is a proposal and requires product/UX review because one denied optional field might be safely omitted rather than block an entire task. That policy must be explicit; the executor must never improvise.

## Compatibility with NEXY principles

Potential alignment:
- zero guess → unknown authority/classification freezes;
- one controlled output → one boundary decision per normalized flow;
- human authority → explicit user-authorized gates;
- model independence → no provider-specific behavior in decision core;
- provenance-aware memory → required provenance + policy version;
- security/data minimization → explicit field minimization plan;
- deterministic core → no hidden clock/random/network/model I/O.

## Integration non-goals

This document does not authorize:
- new production routes;
- DB schema changes;
- NEXY policy changes;
- UI changes;
- automatic classification by LLM;
- data migration;
- legal claims.
