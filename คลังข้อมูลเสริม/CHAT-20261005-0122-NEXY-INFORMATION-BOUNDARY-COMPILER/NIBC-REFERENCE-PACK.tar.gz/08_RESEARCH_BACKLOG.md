# 08 — Research Backlog

All entries are AI-PROPOSED research, not requirements.

## R1 — Semantic minimization
Field names are insufficient when harmless-looking fields contain sensitive meaning. Research deterministic or independently verified semantic tagging without giving an LLM unilateral classification authority.

## R2 — Classification provenance
Attach `who/what classified this`, source evidence, model/tool version if used, review state, and expiry to every classification.

## R3 — Consent receipts
Define a purpose-bound, scope-bound, versioned consent receipt so consent cannot be replayed for a different purpose/destination.

## R4 — Destination capability attestation
Destinations may change retention/training/logging behavior. Design admission records with freshness windows and explicit stale behavior.

## R5 — Shadow-copy graph
Model caches, logs, queues, backups, generated artifacts, embeddings, vector stores, and third-party provider copies so deletion obligations refer to a graph rather than one resource ID.

## R6 — Deletion evidence levels
Separate:
- request accepted;
- primary record removed;
- indexes/caches removed;
- backups expired/tombstoned;
- third-party provider acknowledgment;
- independently verified absence.

Avoid calling all of these simply “deleted.”

## R7 — Information-flow composition
Study whether per-item decisions safely compose for bundles, derived data, summaries, embeddings, and model-generated outputs.

## R8 — Derived/inferred sensitivity
A model output may infer sensitive data not explicitly present in inputs. Explore taint/provenance propagation into derived artifacts.

## R9 — Data-budget compiler
Represent per-task disclosure budgets: maximum fields, tokens, destinations, retention, and number of external hops.

## R10 — Local-first routing
When two tools/models can satisfy a task, measure whether a local route can preserve utility while avoiding external disclosure.

## R11 — Policy diff and migration simulator
Given policy vN → vN+1, enumerate data/flows that change from ALLOW↔DENY↔FREEZE and require explicit migration decisions.

## R12 — Purpose taxonomy quality
Measure whether purpose labels are too broad and allow “purpose laundering.” Define canonical, bounded purpose semantics and adversarial tests.

## R13 — User-facing boundary explanation
Without exposing private internals, design concise explanations such as:
- what data is needed;
- where it would go;
- why;
- how long it would remain;
- what is blocked;
- what user action can resolve a freeze.

Coordinate with experience/human-authority work rather than duplicating it.

## R14 — Cross-agent isolation
Use NIBC decisions to produce minimum per-agent context shards and verify that sibling agent context cannot leak through shared state.

## R15 — Jurisdiction/residency extension
Only after authoritative legal requirements are available, compile residency/transfer constraints as a separate governed policy layer. Do not derive legal requirements from model memory.

## R16 — Side-channel evidence
Test whether reason timing, error detail, cache behavior, and audit metadata reveal sensitive existence even when payload disclosure is denied.

## R17 — High-volume performance
Benchmark rule count, data-class count, field count, and batch composition. Set explicit latency/resource budgets only from measured evidence.

## R18 — Formal model
Translate key invariants into a model checker or proof system:
- no clearance bypass;
- no external disclosure without configured authority;
- conflict cannot release ALLOW;
- over-retention cannot release ALLOW.
