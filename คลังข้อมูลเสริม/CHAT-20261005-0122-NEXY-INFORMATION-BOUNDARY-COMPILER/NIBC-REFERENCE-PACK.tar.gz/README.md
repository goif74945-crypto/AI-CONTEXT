# NEXY Information Boundary Compiler (NIBC)

Status: AI-PROPOSED / SUPPLEMENTAL R&D / REFERENCE PROTOTYPE
Execution code: `CHAT-20261005-0122-NEXY-INFORMATION-BOUNDARY-COMPILER`
Storage target: `goif74945-crypto/AI-CONTEXT/คลังข้อมูลเสริม/CHAT-20261005-0122-NEXY-INFORMATION-BOUNDARY-COMPILER`
NEXY.AI implementation repositories: PROTECTED / NOT MODIFIED

## Why this exists

NIBC explores a missing control-plane question:

> Given a piece of information, a purpose, an operation, a destination, user authority, consent state, retention request, and provenance, is the information flow allowed, denied, or too ambiguous to proceed?

The proposal turns that question into a deterministic, fail-closed compile step before data is disclosed to an agent/tool, retained in durable memory, exported, or deleted.

The reference prototype intentionally has no network, filesystem, clock, random, environment, database, or model dependency in its decision core. It accepts explicit policy + request values and emits one deterministic decision object.

## Core output

Every evaluation returns exactly one of:

- `ALLOW` — all required gates passed; optional minimization transforms/obligations may be attached.
- `DENY` — policy or authority explicitly prohibits the flow.
- `FREEZE` — a material fact, identity, authority state, provenance field, policy contract, or conflict is unresolved/invalid.

This matches the NEXY design principle of controlled release rather than guessing through missing information.

## Implemented reference gates

1. contract validity
2. data-class identity
3. destination identity
4. sensitivity/clearance comparison
5. purpose limitation
6. operation limitation
7. destination allow-list
8. explicit policy-rule resolution with equal-priority conflict freeze
9. consent state for external destinations
10. explicit user authority for protected external disclosure
11. durable-storage eligibility
12. retention limit enforcement without silent clipping
13. deletion target + user authority + deletion-proof obligations
14. field-level minimization plan (`DROP_FIELDS`)
15. provenance requirement
16. deterministic release decision + audit obligation

## What this is not

- not a canonical NEXY requirement;
- not proof that NEXY.AI currently implements these controls;
- not a legal-compliance certification;
- not a complete privacy/security system;
- not a cryptographic deletion proof implementation;
- not a content classifier that guesses sensitivity from raw text;
- not authorization to modify or deploy NEXY.AI.

## Run the reference validation

```bash
python -m pip install -r requirements-dev.txt
python tools/validate.py
```

The validator checks JSON parsing, Draft 2020-12 schema conformance, Python syntax, unit/adversarial tests, and emits `execution-evidence.json` with hashes of critical tested content.

## Read order

1. `00_SESSION_MEMORY.md`
2. `01_MANIFEST.md`
3. `02_ARCHITECTURE.md`
4. `03_REQUIREMENT_LEDGER.md`
5. `04_POLICY_CONTRACT.md`
6. `05_THREAT_FAILURE_MODEL.md`
7. `06_INTEGRATION_PROPOSAL.md`
8. `07_ADOPTION_GATES.md`
9. `08_RESEARCH_BACKLOG.md`
10. `09_VALIDATION_REPORT.md`
11. `10_FINAL_AUDIT.md`
