# NEXY EPC Assumption & Identifiability Kernel 20 (AIK20)

AI-proposed Lo4 reference package for the **NEXY Evolutionary Proposal Court (EPC)**.

AIK20 addresses a narrow failure mode: a proposal can appear well-evidenced while relying on hidden premises or while multiple decision-distinct explanations remain compatible with the same observations. The package exposes assumptions, binds them to provenance/baselines/defeaters, and checks whether evidence actually identifies a decision-relevant outcome.

It is **not Canon**, **not NEXY runtime code**, and **cannot promote anything**. Its strongest action is an advisory `DEFER`/review result.

See:
- `docs/04_DESIGN_AIK20.md` for the 20 mechanisms;
- `docs/03_NOVELTY_COLLISION_AUDIT.md` for de-duplication evidence;
- `docs/07_EVIDENCE.md` for executed test evidence;
- `docs/09_VOTE_PROTOCOL.md` for EPC voting law.

Verification:

```text
npm run verify
```
