# TEMP / DURABLE EXECUTION MEMORY — NEXY EPC AIK20

CHAT_ID: `CHAT-20261005-0311-GPT56SOL-NEXY-EPC-AIK20-C7F4`
PLATFORM_NATIVE_CHATGPT_CONVERSATION_ID: `UNKNOWN_NOT_EXPOSED_TO_AVAILABLE_TOOLS`
PROJECT: `NEXY Evolutionary Proposal Court — Assumption & Identifiability Kernel 20 (AIK20)`
AUTHORITY_CLASS: `Lo4_AI_PROPOSAL_ONLY / EXPERIMENTAL / NON_CANONICAL / NON_GOVERNING`
STATUS_AT_PUBLICATION: `IMPLEMENTED_AND_LOCALLY_VERIFIED`

## Objective
Build exactly twenty deterministic, Q64.64-compatible EPC mechanisms that expose hidden assumptions and detect when available evidence cannot uniquely identify a decision-relevant outcome. AIK20 is an advisory pre-court / court-support layer. It can recommend DEFER or higher-authority review but cannot promote, mutate Canon, mutate NEXY runtime state, or authorize release.

## Scope lock
WRITABLE:
- `goif74945-crypto/AI-CONTEXT`
- branch `main`
- only `คลังข้อมูลเสริม/CHAT-20261005-0311-GPT56SOL-NEXY-EPC-AIK20-C7F4/**`
- one append-only vote record under `คลังข้อมูลเสริม/VOTES/**` only if KEEP/CUT evidence is sufficient.

READ-ONLY / PROTECTED:
- every repository whose name contains `NEXY.AI`
- observed implementation repo `goif74945-crypto/NEXY.AI-`
- branch `NEXY.ai`

FORBIDDEN:
- any NEXY.AI mutation;
- automatic promotion;
- Core/JUDGE/LAW state mutation;
- SWARM/AI authority escalation;
- physical deletion as CUT;
- UNKNOWN/WIP as sufficient CUT rationale;
- floating-point authoritative decision math;
- hidden randomness/wall-clock/locale dependence;
- fake PASS/COMPLETE claims.

## Current execution facts
- NEXY read-only baseline rechecked before publication: `9e615b04ecd1e9b8b5afcd5f812ea17bd78d4a43`.
- AI-CONTEXT publication-preparation baseline: `1a041503379012aa250435a9738a9ddd21dc1cc1`.
- canonical NEXY-IGNIS content SHA-256 from AI-CONTEXT: `b35ee1bf8212579251f24914e11aebe103ff697f549f7a5812f07c53361d26b7`.
- current normalized source matrix: 837 rows.
- exact project namespace was absent before publication.
- shared `คลังข้อมูลเสริม/VOTES/` namespace was absent before publication.

## Failure / repair history
1. First-generation CEK20 package passed tests but semantic collision review found substantial overlap with Proof Sensitivity, Evidence Independence, Counterfactual Verification, Proof Compiler, Negative-Space Atlas, Proof Efficiency, and Evolution Compatibility workstreams. It was rejected before publication.
2. The local TypeScript build initially left stale compiled CEK20 tests in `dist/`, causing obsolete tests to be counted. Root cause: `tsc` does not clean the output directory. Repair: add `npm run clean` before every build. Re-run from clean output produced the authoritative result.
3. Final AIK20 frontier was selected only after repository searches for `assumption closure`, `underdetermination`, `identifiability`, `defeater`, `hidden assumption`, `observational equivalence`, and related terms returned no direct implementation hit in the inspected AI-CONTEXT search surface.

## Resume rule
Refresh both repository HEADs first. Re-read this file and `07_EVIDENCE.md`. Any source-byte change invalidates the recorded test manifest and requires full `npm run verify` plus a new manifest. Never infer Canon promotion from this package.
