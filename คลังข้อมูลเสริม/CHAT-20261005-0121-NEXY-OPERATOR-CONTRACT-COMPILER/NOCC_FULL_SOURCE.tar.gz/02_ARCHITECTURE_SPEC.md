# NOCC Architecture Specification

Status: **AI_PROPOSAL / IMPLEMENTED AS SUPPLEMENTAL REFERENCE / NOT INTEGRATED WITH NEXY.AI**

## 1. Objective

Create a deterministic and auditable translation layer between authoritative NEXY state and operator-facing control/presentation surfaces.

The key problem is not text formatting. The problem is semantic drift across boundaries. A UI can be visually polished yet still lie by:

- displaying a result before release gates pass;
- enabling a control because it is visible;
- hiding FREEZE behind a generic error state;
- treating loading as implied success;
- omitting incident metadata needed for lawful recovery;
- leaking implementation/debug details to roles that should not see them;
- inventing a fallback when input state is incomplete.

NOCC makes those conditions explicit and machine-checkable.

## 2. Governing source-derived constraints

Source class: AI-CONTEXT project context, not runtime evidence.

Relevant authority inputs loaded for this design:

- `projects/NEXY.AI/overview.md`
- `projects/NEXY.AI/deep/doc-c-vnext-build-spec.md`
- `projects/NEXY.AI/deep/doc-d-product-design.md`
- `projects/NEXY.AI/deep/human-control-surface.md`
- `projects/NEXY.AI/source-normalization/CURRENT-SYSTEM-FEATURE-BUILD-MATRIX.md`
- global AI-CONTEXT execution/security/verification rules.

Important preserved facts:

- current SystemState vocabulary: INIT, READY, RUNNING, VERIFYING, CONSENSUS, STABLE, FREEZE, STOP;
- current SystemStatus vocabulary: OK, DEGRADED, FREEZE, STOP;
- current roles include OWNER, OPERATOR, AUDITOR, SYSTEM, PUBLIC_USER;
- UI must reflect backend truth;
- visible != editable != executable;
- release must not occur through unresolved conflict or failed release policy;
- FREEZE blocks release and requires explicit incident semantics;
- STOP is irreversible in the current build model;
- the UI is not authority and cannot replace backend enforcement.

## 3. Non-goals

NOCC does not become a new authority layer. It is not permitted to:

- override release policy;
- calculate final consensus confidence;
- authorize backend mutations;
- recover FREEZE by itself;
- convert PARTIAL/UNKNOWN state into success;
- infer missing incident fields;
- replace server-side RBAC;
- change current NEXY build scope.

## 4. Architecture

```text
Core/API authoritative snapshot
        |
        v
Strict Snapshot Validator
  - known-field lock
  - enum lock
  - state/status consistency
  - release consistency
  - evidence consistency
  - FREEZE metadata completeness
        |
        v
Operator Policy Engine
  - role x state x surface
  - visible/editable/executable split
  - denial reason codes
        |
        +-------------------+
        |                   |
        v                   v
Presentation Compiler   Evidence Normalizer
  message_key           stable ordering
  reason codes          contradiction flags
  redaction             verified flags
        |                   |
        +---------+---------+
                  v
        Deterministic Contract
                  |
                  v
          Canonical JSON + SHA-256
```

## 5. Module ownership

### `validation.py`
Owns the truth boundary.

Responsibilities:
- reject unknown fields;
- reject unsupported enum values;
- enforce required fields;
- enforce FREEZE/STOP state-status agreement;
- reject releaseable outputs outside STABLE;
- reject releaseable output when release policy failed;
- reject releaseable output with evidence below the supplied policy minimum;
- reject releaseable output with contradictions;
- reject result summaries when the output is not releaseable;
- reject duplicate evidence identities.

Failure behavior: raise `ContractValidationError`; never repair silently.

### `policy.py`
Owns operator control decisions.

Responsibilities:
- derive controls from role/state/surface;
- model each control as visible/editable/executable separately;
- retain denial reason codes for auditability;
- assert that read-only roles never execute mutating actions.

It is intentionally not an authentication system.

### `compiler.py`
Owns deterministic contract assembly.

Responsibilities:
- compile message key/reason codes;
- normalize evidence;
- apply presentation redaction;
- attach role/surface data;
- attach control decisions;
- attach FREEZE state data;
- generate SHA-256 contract identity;
- verify basic tamper/invariant conditions on compiled contracts.

### `canonical.py`
Owns stable serialization identity.

The canonical encoding uses sorted JSON keys and fixed separators before SHA-256 hashing.

### `redaction.py`
Owns narrow best-effort presentation hygiene for common secret-shaped strings.

This is deliberately not represented as a production DLP/security guarantee.

### `matrix.py`
Owns deterministic policy-matrix export.

It compiles the Cartesian product:

`8 states x 5 roles x 3 surfaces = 120 scenarios`.

The matrix is useful for permission drift review and future policy-version diffs.

## 6. Input contract

The compiler requires:

- request identity;
- trace identity;
- observation time;
- SystemStatus;
- SystemState;
- actor role;
- selected surface;
- releaseable flag;
- release-policy result + evidence minimum;
- evidence set;
- optional release result summary;
- optional error code;
- mandatory structured FREEZE object in FREEZE;
- optional warnings.

Unknown fields fail closed so new semantics cannot appear unnoticed.

## 7. Output contract

The output contains:

- schema and policy versions;
- source request/trace/time identity;
- `truth` block;
- `operator` block;
- `presentation` block;
- normalized evidence + counts;
- control decisions;
- FREEZE metadata when applicable;
- diagnostic visibility contract;
- deterministic SHA-256.

The output explicitly sets `hidden_reasoning_exposed=false` because the intended user surface is a reason/evidence summary, not model-private reasoning.

## 8. Invariants

### I-01 Determinism
Equivalent normalized inputs generate identical compiled output and identical SHA-256.

### I-02 No false release
`releaseable=true` is legal only for STABLE + passed release policy + sufficient verified evidence + zero contradictory evidence + a result summary.

### I-03 FREEZE truth
FREEZE requires SystemState=FREEZE and SystemStatus=FREEZE, with incident code, trigger, blocking layer, recoverability, and primary reason code.

### I-04 STOP truth
STOP cannot be releaseable and exposes no executable mutating control in the reference policy.

### I-05 Read-only authority
AUDITOR and PUBLIC_USER never execute SUBMIT_DIRECTIVE, SAVE_DRAFT, or RECOVER.

### I-06 Recovery authority
RECOVER is executable only for OWNER in a recoverable FREEZE snapshot.

### I-07 No invisible execution
A control may not be editable or executable unless it is visible.

### I-08 Unknown-field lock
Unknown top-level or nested semantic fields are rejected rather than ignored.

### I-09 Evidence identity
Evidence IDs must be unique inside one snapshot.

### I-10 Tamper signal
A modified compiled payload no longer verifies against its recorded contract hash.

## 9. Failure model

| Failure | Result |
|---|---|
| missing required snapshot field | compile FAIL |
| unknown semantic field | compile FAIL |
| FREEZE metadata incomplete | compile FAIL |
| state/status conflict | compile FAIL |
| releaseable outside STABLE | compile FAIL |
| release-policy failed | compile FAIL |
| evidence minimum not met | compile FAIL |
| contradictory evidence on release | compile FAIL |
| duplicate evidence identity | compile FAIL |
| output tampered after compile | verifier returns false |

No hidden fallback is defined.

## 10. Security boundary

The compiler is designed to reduce UI authorization drift, not to become security authority.

Required future integration law:

- backend authorization remains authoritative;
- the compiler output may drive UI affordances but never grant a permission that the backend does not independently enforce;
- input must originate from a trusted backend envelope or a verified adapter;
- redaction is a last presentation layer, not secret-management infrastructure;
- contract hash is integrity identity, not a signature and not proof of trusted origin.

## 11. Observability proposal

A future integrated implementation should emit:

- policy_version;
- schema_version;
- input state/status/role/surface;
- compilation status;
- denial reason-code counts;
- contract hash;
- source request_id/trace_id;
- policy-drift alert when generated matrix hash changes;
- validation failure code without echoing sensitive payloads.

## 12. Version/evolution law

Any semantic change to:

- role behavior;
- state behavior;
- action IDs;
- denial semantics;
- required input fields;
- release consistency checks;
- output meaning

must bump policy/schema version as appropriate and regenerate the policy matrix.

A changed matrix digest without an intentional version change should be treated as a review failure.

## 13. Evidence boundary

What this implementation proves:

- source code parses/compiles in the observed Python environment (E1);
- isolated compiler/policy/CLI behaviors pass executed unit tests (E2);
- exhaustive baseline policy combinations compile deterministically (E2).

What it does not prove:

- NEXY API integration (E3);
- real browser/operator flow (E4);
- production runtime behavior (E5);
- deployment correctness (E6).
