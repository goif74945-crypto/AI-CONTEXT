# NOCC Requirement / Evidence Ledger

Status vocabulary follows AI-CONTEXT verification law.

| ID | Requirement | Authority / rationale | Implementation | Evidence | Status |
|---|---|---|---|---|---|
| R-001 | Keep proposal separate from current NEXY.AI implementation | user scope + AI-CONTEXT mutation boundary | entire project path; docs classification | repository target/path review | PASS |
| R-002 | Reflect canonical SystemState vocabulary | DOC-C deep context | `constants.py`, validator | unit/matrix tests | PASS |
| R-003 | Reflect canonical role vocabulary | DOC-C deep context | `constants.py`, validator | unit/matrix tests | PASS |
| R-004 | Preserve UI truth; no result before release | DOC-C/DOC-D | `validation.py`, `compiler.py` | negative tests | PASS |
| R-005 | Treat visible/editable/executable separately | human-control-surface + DOC-D | `policy.py` | action invariant matrix test | PASS |
| R-006 | FREEZE must be explicit | DOC-C/DOC-D | `validation.py`, compiler FREEZE block | missing-metadata + recovery tests | PASS |
| R-007 | STOP must not expose executable mutation in proposal | DOC-C STOP semantics | `policy.py`, verifier | every-role STOP test | PASS |
| R-008 | PUBLIC_USER/AUDITOR cannot execute modeled mutations | current roles + public-write exclusion + product permissions | `policy.py` | all-state read-only test | PASS |
| R-009 | OWNER recovery only when recoverable FREEZE | DOC-C/DOC-D | `policy.py` | role matrix + nonrecoverable test | PASS |
| R-010 | Unknown semantic fields fail closed | zero-guess / strict boundary design | `validation.py` | top/nested unknown-field tests | PASS |
| R-011 | Contradictory evidence cannot coexist with releaseable presentation | NEXY release/no unresolved conflict principles | `validation.py` | contradiction negative test | PASS |
| R-012 | Evidence minimum must be respected when snapshot says releaseable | DOC-C release policy structure | `validation.py` | insufficient-evidence test | PASS |
| R-013 | Same normalized input produces same output identity | deterministic design target | `canonical.py`, sorted normalization | repeat + evidence-order tests | PASS |
| R-014 | Tampering invalidates recorded hash identity | integrity requirement for machine contract | `verify_compiled_contract` | tamper test | PASS |
| R-015 | CLI must fail nonzero on invalid input | fail-closed operator tooling | `cli.py` | CLI failure test | PASS |
| R-016 | Common secret-shaped strings should be redacted from presentation fields | AI-CONTEXT security/data-minimization direction | `redaction.py` | redaction tests | PASS (narrow) |
| R-017 | Policy drift must be reproducibly inspectable | future maintainability | `matrix.py`, export tool | 120-row deterministic matrix tests | PASS |
| R-018 | Do not expose hidden chain-of-thought as a requirement | AI-CONTEXT model independence + NEXY reason-summary model | output diagnostics + structured reasons | structural inspection/unit outputs | PASS |
| R-019 | Machine-readable schemas exist | explicit contracts | `schemas/*.json` | JSON parse test | PASS (shape only) |
| R-020 | Integration with NEXY.AI is not claimed | scope/evidence law | docs and final audit | no NEXY.AI mutation/integration executed | NOT_VERIFIED / NOT_PERFORMED by design |

## Evidence class summary

- E0 Presence: planned files exist locally before publication.
- E1 Static: Python compileall PASS; schema documents parse as JSON.
- E2 Unit: 36 executed tests PASS.
- E3 Integration: NOT PERFORMED.
- E4 E2E/browser: NOT PERFORMED.
- E5 Runtime/operational: NOT PERFORMED.
- E6 Deployment: NOT PERFORMED.

No higher evidence class is implied by lower-class success.
