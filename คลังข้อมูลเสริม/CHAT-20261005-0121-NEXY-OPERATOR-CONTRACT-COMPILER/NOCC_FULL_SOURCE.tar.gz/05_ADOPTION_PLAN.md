# NOCC Future Adoption Plan

Classification: **AI_PROPOSAL — adoption is not authorized by this document.**

The reference implementation should not be copied directly into NEXY.AI merely because its isolated tests pass. Future adoption must be a separate authorized task against the then-current DOC-C/DOC-D, repository head, and runtime evidence.

## Phase 0 — Spec promotion gate

Required before implementation integration:

- authorized source explicitly promotes an operator-contract layer or equivalent behavior;
- exact current action/permission matrix is defined;
- whether NOCC is a library, API boundary, UI adapter, or build-time generated contract is decided;
- policy/schema version ownership is assigned;
- current NEXY repository head is inspected fresh.

If not promoted, remain supplemental only.

## Phase 1 — Contract reconciliation

Map NOCC fields against exact current:

- SystemEnvelope;
- runtime Zod schemas;
- RBAC rules;
- release-policy output;
- incident/freeze record;
- UI component props;
- audit event schema.

Every mismatch must be classified as:

- source drift;
- proposal drift;
- naming-only difference;
- semantic conflict;
- missing current requirement.

No silent mapping.

## Phase 2 — Backend truth adapter

Build a trusted adapter from the authoritative backend response into the compiler input.

Hard rules:

- client does not manufacture state;
- role is supplied from authenticated backend context;
- releaseable comes from authoritative release result;
- incident metadata comes from authoritative incident record;
- evidence metadata is bounded/minimized;
- untrusted model text cannot inject policy/action fields.

Evidence target: E3.

## Phase 3 — Backend authorization cross-check

For each modeled action:

1. UI contract says executable;
2. backend route independently verifies session/role/state/policy;
3. mismatch becomes a test failure and security finding.

The operator contract is never accepted as an authorization token.

## Phase 4 — UI conformance

Bind product components such as StatusChip, FreezeBanner, IncidentCard, PermissionGate, OwnerActionBar, and TrustExplainer to the compiled contract.

Required browser/E2E cases:

- READY owner/operator run flow;
- PUBLIC_USER denied write;
- AUDITOR read-only trace;
- pending states never imply success;
- STABLE unreleased state shows no result;
- releaseable STABLE shows result;
- recoverable FREEZE owner flow;
- nonrecoverable FREEZE disabled recovery;
- STOP has no fake restart;
- mobile sticky FREEZE behavior where current DOC-D still requires it.

Evidence target: E4.

## Phase 5 — Policy-drift CI gate

Generate the policy matrix in CI.

Gate on:

- matrix digest change without policy-version bump;
- newly executable mutating control for read-only roles;
- disappearance of FREEZE/STOP protections;
- unknown new state/role/surface without explicit policy handling;
- output-schema semantic change without version bump.

## Phase 6 — Operational observability

In target runtime, measure:

- compile validation-failure rate;
- state/action mismatch incidents;
- frontend/backend permission mismatches;
- stale policy-version clients;
- policy-matrix version distribution;
- freeze explanation coverage;
- contract-hash mismatch rate.

Evidence target: E5.

## Phase 7 — Security review

Threat-model:

- forged role/state snapshots;
- action-field injection;
- XSS through presentation strings;
- secret leakage through reason/evidence summaries;
- replay of stale operator contracts;
- hash confused with signature/authentication;
- downgrade to an older permissive policy version.

The current regex redactor is insufficient as a security boundary and must remain defense-in-depth only.

## Rollback law

Adoption should be reversible:

- previous policy version retained;
- UI/backend compatibility range explicit;
- no irreversible data migration required solely for NOCC;
- policy-matrix digest archived per release;
- rollback tested before production promotion.
