# NOCC Test and Evidence Record

Observed date context: 2026-10-05 Asia/Bangkok
Environment used for local reference validation: Python 3.13.5

## Claim A — Python source/test/tool syntax is valid in observed environment

Evidence class: E1

Command:

```bash
python -m compileall -q src tests tools
```

Observed result: PASS (exit 0, no compile errors).

Limit: does not prove type soundness under a separate static type checker and does not prove runtime integration.

## Claim B — isolated compiler/policy/CLI behavior satisfies current reference tests

Evidence class: E2

Command:

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
```

Observed result after correction of one test expectation:

- 36 tests executed;
- 36 PASS;
- 0 FAIL;
- 0 ERROR.

The intermediate failed test expected a denied `EXPORT_RESULT` decision to be absent. The implementation intentionally retains denied decisions with `visible=false` and `executable=false` so policy denial remains auditable. The test was corrected to validate that intended semantic. No permission leak was observed.

## Claim C — baseline policy matrix is exhaustive for accepted vocabulary Cartesian product

Evidence class: E2

Dimensions:

- 8 SystemState values;
- 5 roles;
- 3 surfaces.

Total expected = 120.

Observed generated rows = 120 unique scenario keys.

Matrix digest:

`18582b915709a4a30f1955b063456b341c5a197f14828494dd0d5ff04111022c`

Generated artifact: `artifacts/policy-matrix.json`.

## Claim D — deterministic normalization ignores evidence list order

Evidence class: E2

Executed test reverses equivalent evidence order and compares full compiled contracts and final hashes.

Observed: PASS.

## Claim E — tampering is detectable against contract hash

Evidence class: E2

Executed test mutates a compiled presentation message after hashing and calls `verify_compiled_contract`.

Observed: verifier returns false; PASS.

## Negative paths executed

Tests cover at least:

- unknown top-level field;
- unknown nested release-policy field;
- unknown nested evidence field;
- missing FREEZE metadata;
- FREEZE status/state mismatch;
- releaseable outside STABLE;
- unreleased result summary;
- contradictory release evidence;
- insufficient verified evidence;
- release policy passing in STOP;
- duplicate evidence identity;
- bool disguised as integer policy minimum;
- nonrecoverable FREEZE;
- read-only role mutation across all states;
- STOP mutation denial for all roles;
- owner-only recovery;
- CLI invalid-input exit behavior;
- redaction of common secret-shaped strings.

## Unproven claims

The following remain NOT_VERIFIED / NOT_PERFORMED:

- compatibility with current NEXY.AI codebase;
- exact backend RBAC match;
- exact API SystemEnvelope integration;
- browser rendering/UI component behavior;
- live auth/session behavior;
- production security effectiveness;
- performance/latency under load;
- operational/deployment behavior.

No statement in this project should be read as proof of those claims.
