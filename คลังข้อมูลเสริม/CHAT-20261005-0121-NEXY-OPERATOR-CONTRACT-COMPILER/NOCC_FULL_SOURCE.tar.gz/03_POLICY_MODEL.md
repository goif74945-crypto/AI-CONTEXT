# NOCC Policy Model

Status: **AI_PROPOSAL policy for the supplemental reference implementation.**

This policy is intentionally narrower than NEXY's complete future product. It demonstrates how UI/control semantics can be compiled deterministically without pretending to replace backend authority.

## 1. Control decision structure

Every modeled control decision contains:

```text
action_id
visible
editable
executable
reason_codes[]
```

This prevents three concepts from collapsing into one boolean.

A denied control may remain in the machine contract with `visible=false` so policy decisions remain auditable. A UI renderer is expected to honor `visible=false` and not display it.

## 2. Baseline actions

- `VIEW_STATUS` — read current state.
- `SAVE_DRAFT` — local/product draft intent for permitted operator surfaces.
- `SUBMIT_DIRECTIVE` — submit real work through RUN/FORGE when READY and role permits.
- `VIEW_PROGRESS` — observe RUNNING/VERIFYING/CONSENSUS.
- `VIEW_RESULT` — inspect a releaseable STABLE result.
- `EXPORT_RESULT` — export a released result when the role policy permits.
- `VIEW_FREEZE_EXPLANATION` — read explicit frozen state.
- `VIEW_TRACE` — audit/owner trace affordance.
- `RECOVER` — owner recovery affordance only when the freeze is recoverable.

The list is deliberately small. NOCC does not invent controls merely because they sound useful.

## 3. State behavior

### INIT
Only status visibility is modeled.

### READY
OWNER/OPERATOR on RUN or FORGE may receive editable/executable draft+submit controls.
VIEW surface never exposes those write controls.

### RUNNING / VERIFYING / CONSENSUS
Status + progress visibility only. No retry/cancel control is invented because this supplemental model does not have sufficient authority to define it.

### STABLE
A released result is visible only when the validated snapshot says `releaseable=true` and all compiler consistency gates pass.

If STABLE but not releaseable, the message key is `STABLE_NO_RELEASE` and no result summary is accepted.

### FREEZE
Required presentation truth:
- explicit frozen message;
- incident code;
- trigger;
- blocking layer;
- recoverability;
- primary reason code.

OWNER:
- can see RECOVER;
- can execute RECOVER only when `recoverable=true`.

AUDITOR:
- can view trace;
- cannot recover.

Other roles:
- receive read-only freeze explanation;
- cannot recover.

### STOP
No executable mutating control is emitted by this policy. OWNER/AUDITOR may view trace. The reference implementation does not invent a restart control because current source context describes STOP as irreversible in the build model and requiring manual/admin intervention.

## 4. Role behavior

### OWNER
Highest human control surface represented here, but still bound by state law.

### OPERATOR
May submit/save when READY on execution/build surfaces. Cannot recover FREEZE in this proposal.

### AUDITOR
Read-only. May inspect trace and export a released result in the reference policy, but cannot mutate execution state.

### PUBLIC_USER
Read-only in this proposal. This aligns with current vNEXT exclusion of public anonymous write access.

### SYSTEM
Accepted as a canonical actor role in input vocabulary. NOCC intentionally does not provide human write controls to SYSTEM because this library compiles operator-facing contracts rather than internal autonomous execution rights.

## 5. Release consistency checks

NOCC does not recalculate JUDGE/LAW release policy. It performs consistency checks on the authoritative snapshot:

`releaseable=true` requires:

1. SystemState=STABLE;
2. release_policy.passed=true;
3. verified evidence count >= supplied `evidence_min`;
4. contradiction count = 0;
5. result_summary present.

This is a presentation truth guard, not a substitute release authority.

## 6. Deterministic identity

Before hashing:

- evidence is sorted by evidence ID;
- reason codes are normalized/sorted;
- actions are sorted by action ID;
- object keys are serialized in sorted order;
- UTF-8 canonical JSON is SHA-256 hashed.

Equivalent evidence input order therefore does not change contract identity.

## 7. Policy matrix

`tools/export_policy_matrix.py` generates a baseline matrix across:

- 8 SystemState values;
- 5 roles;
- 3 surfaces.

Total: **120 unique scenarios**.

Current generated digest for this revision:

`18582b915709a4a30f1955b063456b341c5a197f14828494dd0d5ff04111022c`

The matrix is not a claim that all 120 scenarios are reachable in the production NEXY FSM. It is a policy-surface enumeration used to detect accidental control drift across the accepted vocabulary.
