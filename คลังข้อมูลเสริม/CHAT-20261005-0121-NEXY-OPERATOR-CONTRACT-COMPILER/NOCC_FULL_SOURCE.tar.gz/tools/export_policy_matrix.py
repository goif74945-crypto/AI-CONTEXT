from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from nexy_operator_contract.matrix import export_policy_matrix  # noqa: E402


def main() -> int:
    destination = ROOT / "artifacts" / "policy-matrix.json"
    destination.write_text(
        json.dumps(export_policy_matrix(), indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(destination)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
