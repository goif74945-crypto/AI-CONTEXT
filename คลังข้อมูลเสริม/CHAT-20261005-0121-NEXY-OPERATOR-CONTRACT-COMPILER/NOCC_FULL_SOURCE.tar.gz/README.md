# NEXY Operator Contract Compiler (NOCC)

> **Classification: AI_PROPOSAL / supplemental reference implementation / NOT current NEXY.AI runtime truth.**
>
> This project lives only in `goif74945-crypto/AI-CONTEXT`. It was intentionally built without modifying any repository whose name contains `NEXY.AI`.

## Why this exists

NEXY's source-derived laws make a strict distinction between system truth and presentation truth:

- the interface must reflect real state;
- visibility is not authorization;
- FREEZE must look frozen;
- a result must not be presented as released unless the authoritative release path says it is releaseable;
- the operator should see the useful result or a clear blocked/frozen state without needing to understand hidden internal machinery.

Those principles are easy to state and surprisingly easy to violate once UI code, role checks, loading states, incident screens, exports, and provider-generated summaries evolve independently.

NOCC is an AI-proposed future bridge between authoritative NEXY state and human-visible control surfaces. It compiles a strict, validated snapshot into a deterministic **operator contract** containing:

- truth state;
- role + surface context;
- user-facing message key;
- explicit reason codes;
- evidence summary;
- legal/denied control decisions;
- FREEZE metadata;
- role-aware diagnostic visibility;
- deterministic SHA-256 contract identity.

## What it does not do

NOCC does **not**:

- decide whether NEXY should release an output;
- replace LAW, CORE, JUDGE, AUTH, or backend RBAC;
- infer missing facts;
- invent permissions;
- expose hidden chain-of-thought;
- claim integration with NEXY.AI;
- prove production UX behavior;
- provide production-grade secret detection.

It consumes already-authoritative state and compiles a presentation/control contract from it.

## Core invariant

```text
AUTHORITATIVE SNAPSHOT
  -> strict validation
  -> consistency checks
  -> policy derivation
  -> presentation-safe normalization
  -> deterministic operator contract
  -> contract hash
```

If the input is materially inconsistent, compilation fails closed.

## Example

```bash
PYTHONPATH=src python -m nexy_operator_contract.cli fixtures/freeze_owner.json --pretty
```

Expected semantics for that fixture:

- state remains `FREEZE`;
- `releaseable=false`;
- incident code/trigger/blocking layer/recoverability remain explicit;
- `RECOVER` is executable only because the role is OWNER and the incident is marked recoverable;
- no result summary is emitted;
- output receives a deterministic `contract_sha256`.

## Validation

Observed local validation environment for this revision:

- Python 3.13.5
- `python -m compileall -q src tests tools` -> PASS
- `PYTHONPATH=src python -m unittest discover -s tests -v` -> 36/36 PASS
- exhaustive non-release policy matrix -> 120 unique state/role/surface scenarios
- generated policy matrix SHA-256 -> `18582b915709a4a30f1955b063456b341c5a197f14828494dd0d5ff04111022c`

Evidence level is E1/E2 only. Integration, browser, runtime, deployment, and NEXY.AI production behavior remain NOT_VERIFIED / NOT_PERFORMED.

## Layout

- `02_ARCHITECTURE_SPEC.md` — design contract and invariants
- `03_POLICY_MODEL.md` — state/role/surface control semantics
- `04_REQUIREMENT_EVIDENCE_LEDGER.md` — traceability from requirement to code/test
- `05_ADOPTION_PLAN.md` — future integration gates
- `06_AI_PROPOSED_FUTURE_SYSTEMS.md` — explicitly non-authoritative expansion ideas
- `07_TEST_AND_EVIDENCE.md` — reproducible evidence record
- `src/nexy_operator_contract/` — reference implementation
- `tests/` — unit, negative, determinism, matrix tests
- `fixtures/` — reproducible input snapshots
- `schemas/` — machine-readable input/output shapes
- `tools/export_policy_matrix.py` — deterministic policy export
- `artifacts/policy-matrix.json` — generated 120-scenario matrix
- `99_FINAL_AUDIT.md` — final scope/quality audit

## Authority boundary

Current NEXY build obligations remain governed by DOC-B/DOC-C/DOC-D/DOC-E according to their documented hierarchy. This project is advisory supplemental engineering work until explicitly promoted by an authorized future specification.
