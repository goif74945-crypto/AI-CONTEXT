from __future__ import annotations

from copy import deepcopy
from typing import Any

from .canonical import sha256_hex
from .constants import POLICY_VERSION, SCHEMA_VERSION
from .policy import derive_actions
from .redaction import redact_sensitive_text
from .validation import ContractValidationError, validate_snapshot


def _evidence_summary(snapshot: dict[str, Any]) -> dict[str, int]:
    evidence = snapshot["evidence"]
    return {
        "total": len(evidence),
        "verified": sum(1 for item in evidence if item["verified"]),
        "contradictory": sum(1 for item in evidence if item["contradiction"]),
    }


def _state_message(snapshot: dict[str, Any]) -> tuple[str, list[str]]:
    state = snapshot["system_state"]
    if state == "INIT":
        return "SYSTEM_INITIALIZING", ["STATE_INIT"]
    if state == "READY":
        return "SYSTEM_READY", ["STATE_READY"]
    if state == "RUNNING":
        return "EXECUTION_IN_PROGRESS", ["STATE_RUNNING"]
    if state == "VERIFYING":
        return "VERIFICATION_IN_PROGRESS", ["STATE_VERIFYING"]
    if state == "CONSENSUS":
        return "CONSENSUS_IN_PROGRESS", ["STATE_CONSENSUS"]
    if state == "STABLE":
        if snapshot["releaseable"]:
            return "VERIFIED_RESULT_AVAILABLE", ["STATE_STABLE", "RELEASE_POLICY_PASSED"]
        return "STABLE_NO_RELEASE", ["STATE_STABLE", "OUTPUT_NOT_RELEASEABLE"]
    if state == "FREEZE":
        freeze = snapshot["freeze"]
        return "SYSTEM_FROZEN", ["STATE_FREEZE", freeze["primary_reason_code"]]
    if state == "STOP":
        return "SYSTEM_STOPPED", ["STATE_STOP", "NO_EXECUTION_ALLOWED"]
    raise AssertionError(f"unreachable state {state}")


def _normalized_evidence(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
    normalized: list[dict[str, Any]] = []
    for item in snapshot["evidence"]:
        row = {
            "id": item["id"],
            "verified": item["verified"],
            "contradiction": item["contradiction"],
        }
        if "summary" in item:
            row["summary"] = redact_sensitive_text(item["summary"])
        normalized.append(row)
    return sorted(normalized, key=lambda item: item["id"])


def compile_contract(raw_snapshot: Any) -> dict[str, Any]:
    snapshot = validate_snapshot(raw_snapshot)
    message_key, reason_codes = _state_message(snapshot)
    actions = [item.to_dict() for item in derive_actions(snapshot)]
    evidence = _normalized_evidence(snapshot)
    evidence_summary = _evidence_summary(snapshot)

    result: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "policy_version": POLICY_VERSION,
        "request_id": snapshot["request_id"],
        "trace_id": snapshot["trace_id"],
        "observed_at": snapshot["observed_at"],
        "truth": {
            "system_status": snapshot["system_status"],
            "system_state": snapshot["system_state"],
            "releaseable": snapshot["releaseable"],
            "release_policy_passed": snapshot["release_policy"]["passed"],
            "error_code": snapshot.get("error_code"),
        },
        "operator": {
            "role": snapshot["actor_role"],
            "surface": snapshot["surface"],
        },
        "presentation": {
            "message_key": message_key,
            "reason_codes": sorted(set(reason_codes)),
            "result_summary": redact_sensitive_text(snapshot["result_summary"])
            if snapshot.get("result_summary")
            else None,
            "warnings": sorted(redact_sensitive_text(x) for x in snapshot.get("warnings", [])),
        },
        "evidence": evidence,
        "evidence_summary": evidence_summary,
        "actions": actions,
        "freeze": deepcopy(snapshot.get("freeze")),
        "diagnostics": {
            "trace_visible": snapshot["actor_role"] in {"OWNER", "AUDITOR"},
            "hidden_reasoning_exposed": False,
        },
    }

    if result["freeze"] is not None:
        for key in ("trigger", "blocking_layer", "primary_reason_code"):
            result["freeze"][key] = redact_sensitive_text(result["freeze"][key])

    hash_input = deepcopy(result)
    result["contract_sha256"] = sha256_hex(hash_input)
    return result


def verify_compiled_contract(contract: Any) -> bool:
    if not isinstance(contract, dict):
        return False
    expected = contract.get("contract_sha256")
    if not isinstance(expected, str) or len(expected) != 64:
        return False
    body = deepcopy(contract)
    body.pop("contract_sha256", None)
    if sha256_hex(body) != expected:
        return False

    truth = contract.get("truth")
    actions = contract.get("actions")
    operator = contract.get("operator")
    if not isinstance(truth, dict) or not isinstance(actions, list) or not isinstance(operator, dict):
        return False

    state = truth.get("system_state")
    role = operator.get("role")
    if state in {"FREEZE", "STOP"} and truth.get("releaseable"):
        return False
    if role in {"AUDITOR", "PUBLIC_USER"}:
        forbidden = {"SUBMIT_DIRECTIVE", "SAVE_DRAFT", "RECOVER"}
        if any(a.get("action_id") in forbidden and a.get("executable") for a in actions if isinstance(a, dict)):
            return False
    if state == "STOP":
        mutating = {"SUBMIT_DIRECTIVE", "SAVE_DRAFT", "RECOVER"}
        if any(a.get("action_id") in mutating and a.get("executable") for a in actions if isinstance(a, dict)):
            return False
    return True


__all__ = ["ContractValidationError", "compile_contract", "verify_compiled_contract"]
