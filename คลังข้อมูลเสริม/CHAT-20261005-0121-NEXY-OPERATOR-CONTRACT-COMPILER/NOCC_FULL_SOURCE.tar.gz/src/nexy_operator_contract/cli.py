from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .compiler import ContractValidationError, compile_contract


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="nocc",
        description="Compile a NEXY operator-facing truth contract from a JSON snapshot.",
    )
    parser.add_argument("input", type=Path, help="Input snapshot JSON file")
    parser.add_argument("--pretty", action="store_true", help="Pretty-print output JSON")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        raw = json.loads(args.input.read_text(encoding="utf-8"))
        contract = compile_contract(raw)
    except (OSError, json.JSONDecodeError, ContractValidationError) as exc:
        print(json.dumps({"status": "FAIL", "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2

    if args.pretty:
        print(json.dumps(contract, indent=2, sort_keys=True, ensure_ascii=False))
    else:
        print(json.dumps(contract, sort_keys=True, separators=(",", ":"), ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
