from __future__ import annotations

from dataclasses import dataclass

from .constants import MUTATING_ACTIONS, READ_ONLY_ROLES


@dataclass(frozen=True, slots=True)
class ActionDecision:
    action_id: str
    visible: bool
    editable: bool
    executable: bool
    reason_codes: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "action_id": self.action_id,
            "visible": self.visible,
            "editable": self.editable,
            "executable": self.executable,
            "reason_codes": list(self.reason_codes),
        }


def _decision(
    action_id: str,
    *,
    visible: bool,
    editable: bool = False,
    executable: bool = False,
    reasons: tuple[str, ...] = (),
) -> ActionDecision:
    if executable and not visible:
        raise AssertionError(f"policy bug: executable action {action_id} must be visible")
    if editable and not visible:
        raise AssertionError(f"policy bug: editable action {action_id} must be visible")
    return ActionDecision(action_id, visible, editable, executable, tuple(sorted(set(reasons))))


def derive_actions(snapshot: dict[str, object]) -> list[ActionDecision]:
    role = str(snapshot["actor_role"])
    state = str(snapshot["system_state"])
    surface = str(snapshot["surface"])
    releaseable = bool(snapshot["releaseable"])

    actions: list[ActionDecision] = [
        _decision("VIEW_STATUS", visible=True, executable=True),
    ]

    if state == "READY":
        can_write = role in {"OWNER", "OPERATOR"}
        actions.extend(
            [
                _decision(
                    "SAVE_DRAFT",
                    visible=can_write and surface in {"RUN", "FORGE"},
                    editable=can_write and surface in {"RUN", "FORGE"},
                    executable=can_write and surface in {"RUN", "FORGE"},
                    reasons=() if can_write else ("ROLE_READ_ONLY",),
                ),
                _decision(
                    "SUBMIT_DIRECTIVE",
                    visible=can_write and surface in {"RUN", "FORGE"},
                    editable=can_write and surface in {"RUN", "FORGE"},
                    executable=can_write and surface in {"RUN", "FORGE"},
                    reasons=() if can_write else ("ROLE_EXECUTION_FORBIDDEN",),
                ),
            ]
        )

    if state in {"RUNNING", "VERIFYING", "CONSENSUS"}:
        actions.append(_decision("VIEW_PROGRESS", visible=True, executable=True))

    if state == "STABLE" and releaseable:
        actions.append(_decision("VIEW_RESULT", visible=True, executable=True))
        can_export = role in {"OWNER", "OPERATOR", "AUDITOR"}
        actions.append(
            _decision(
                "EXPORT_RESULT",
                visible=can_export,
                executable=can_export,
                reasons=() if can_export else ("ROLE_EXPORT_FORBIDDEN",),
            )
        )

    if state == "FREEZE":
        freeze = snapshot["freeze"]
        assert isinstance(freeze, dict)
        actions.append(_decision("VIEW_FREEZE_EXPLANATION", visible=True, executable=True))
        can_trace = role in {"OWNER", "AUDITOR"}
        actions.append(
            _decision(
                "VIEW_TRACE",
                visible=can_trace,
                executable=can_trace,
                reasons=() if can_trace else ("ROLE_TRACE_RESTRICTED",),
            )
        )
        is_owner = role == "OWNER"
        recoverable = bool(freeze["recoverable"])
        actions.append(
            _decision(
                "RECOVER",
                visible=is_owner,
                editable=False,
                executable=is_owner and recoverable,
                reasons=()
                if is_owner and recoverable
                else (("FREEZE_NOT_RECOVERABLE",) if is_owner else ("OWNER_REQUIRED",)),
            )
        )

    if state == "STOP":
        can_trace = role in {"OWNER", "AUDITOR"}
        actions.append(
            _decision(
                "VIEW_TRACE",
                visible=can_trace,
                executable=can_trace,
                reasons=() if can_trace else ("ROLE_TRACE_RESTRICTED",),
            )
        )

    if role in READ_ONLY_ROLES:
        for action in actions:
            if action.action_id in MUTATING_ACTIONS and action.executable:
                raise AssertionError(f"policy bug: read-only role {role} can execute {action.action_id}")

    return sorted(actions, key=lambda item: item.action_id)
