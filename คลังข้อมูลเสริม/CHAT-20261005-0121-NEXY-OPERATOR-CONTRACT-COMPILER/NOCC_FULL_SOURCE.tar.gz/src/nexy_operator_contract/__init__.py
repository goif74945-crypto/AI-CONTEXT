"""NEXY Operator Contract Compiler (AI-proposed supplemental reference implementation)."""

from .compiler import ContractValidationError, compile_contract, verify_compiled_contract

__all__ = ["ContractValidationError", "compile_contract", "verify_compiled_contract"]
__version__ = "0.1.0"
