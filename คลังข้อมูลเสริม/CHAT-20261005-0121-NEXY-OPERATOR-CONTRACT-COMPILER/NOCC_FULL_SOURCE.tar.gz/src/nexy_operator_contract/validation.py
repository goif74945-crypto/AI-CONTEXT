from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from .constants import (
    MAX_EVIDENCE_ITEMS,
    MAX_ID_CHARS,
    MAX_REASON_CHARS,
    MAX_SUMMARY_CHARS,
    ROLES,
    SURFACES,
    SYSTEM_STATES,
    SYSTEM_STATUSES,
)


class ContractValidationError(ValueError):
    """Raised when input violates the operator-contract truth boundary."""


_ALLOWED_TOP = frozenset(
    {
        "request_id",
        "trace_id",
        "system_status",
        "system_state",
        "actor_role",
        "surface",
        "releaseable",
        "release_policy",
        "result_summary",
        "error_code",
        "freeze",
        "evidence",
        "warnings",
        "observed_at",
    }
)
_ALLOWED_RELEASE_POLICY = frozenset({"passed", "evidence_min"})
_ALLOWED_FREEZE = frozenset(
    {"incident_code", "trigger", "blocking_layer", "recoverable", "primary_reason_code"}
)
_ALLOWED_EVIDENCE = frozenset({"id", "verified", "contradiction", "summary"})


def _require_keys(obj: Mapping[str, Any], required: set[str], where: str) -> None:
    missing = sorted(required - set(obj))
    if missing:
        raise ContractValidationError(f"{where}: missing required keys: {', '.join(missing)}")


def _reject_unknown(obj: Mapping[str, Any], allowed: frozenset[str], where: str) -> None:
    unknown = sorted(set(obj) - allowed)
    if unknown:
        raise ContractValidationError(f"{where}: unknown keys are forbidden: {', '.join(unknown)}")


def _require_string(value: Any, where: str, *, max_chars: int, allow_empty: bool = False) -> str:
    if not isinstance(value, str):
        raise ContractValidationError(f"{where}: expected string")
    if not allow_empty and not value.strip():
        raise ContractValidationError(f"{where}: must not be empty")
    if len(value) > max_chars:
        raise ContractValidationError(f"{where}: exceeds {max_chars} characters")
    return value


def validate_snapshot(raw: Any) -> dict[str, Any]:
    if not isinstance(raw, Mapping):
        raise ContractValidationError("snapshot: expected object")
    snapshot = dict(raw)
    _reject_unknown(snapshot, _ALLOWED_TOP, "snapshot")
    _require_keys(
        snapshot,
        {
            "request_id",
            "trace_id",
            "system_status",
            "system_state",
            "actor_role",
            "surface",
            "releaseable",
            "release_policy",
            "evidence",
            "observed_at",
        },
        "snapshot",
    )

    for key in ("request_id", "trace_id", "observed_at"):
        _require_string(snapshot[key], f"snapshot.{key}", max_chars=MAX_ID_CHARS)

    if snapshot["system_status"] not in SYSTEM_STATUSES:
        raise ContractValidationError("snapshot.system_status: unsupported value")
    if snapshot["system_state"] not in SYSTEM_STATES:
        raise ContractValidationError("snapshot.system_state: unsupported value")
    if snapshot["actor_role"] not in ROLES:
        raise ContractValidationError("snapshot.actor_role: unsupported value")
    if snapshot["surface"] not in SURFACES:
        raise ContractValidationError("snapshot.surface: unsupported value")
    if type(snapshot["releaseable"]) is not bool:
        raise ContractValidationError("snapshot.releaseable: expected boolean")

    release_policy = snapshot["release_policy"]
    if not isinstance(release_policy, Mapping):
        raise ContractValidationError("snapshot.release_policy: expected object")
    release_policy = dict(release_policy)
    _reject_unknown(release_policy, _ALLOWED_RELEASE_POLICY, "snapshot.release_policy")
    _require_keys(release_policy, {"passed", "evidence_min"}, "snapshot.release_policy")
    if type(release_policy["passed"]) is not bool:
        raise ContractValidationError("snapshot.release_policy.passed: expected boolean")
    if type(release_policy["evidence_min"]) is not int or release_policy["evidence_min"] < 0:
        raise ContractValidationError("snapshot.release_policy.evidence_min: expected non-negative integer")
    snapshot["release_policy"] = release_policy

    evidence = snapshot["evidence"]
    if not isinstance(evidence, list):
        raise ContractValidationError("snapshot.evidence: expected array")
    if len(evidence) > MAX_EVIDENCE_ITEMS:
        raise ContractValidationError(f"snapshot.evidence: exceeds {MAX_EVIDENCE_ITEMS} items")
    normalized_evidence: list[dict[str, Any]] = []
    seen_ids: set[str] = set()
    for i, item in enumerate(evidence):
        where = f"snapshot.evidence[{i}]"
        if not isinstance(item, Mapping):
            raise ContractValidationError(f"{where}: expected object")
        item = dict(item)
        _reject_unknown(item, _ALLOWED_EVIDENCE, where)
        _require_keys(item, {"id", "verified", "contradiction"}, where)
        evidence_id = _require_string(item["id"], f"{where}.id", max_chars=MAX_ID_CHARS)
        if evidence_id in seen_ids:
            raise ContractValidationError(f"{where}.id: duplicate evidence id")
        seen_ids.add(evidence_id)
        if type(item["verified"]) is not bool or type(item["contradiction"]) is not bool:
            raise ContractValidationError(f"{where}: verified and contradiction must be booleans")
        if "summary" in item:
            item["summary"] = _require_string(
                item["summary"], f"{where}.summary", max_chars=MAX_REASON_CHARS
            )
        normalized_evidence.append(item)
    snapshot["evidence"] = normalized_evidence

    for optional_string, max_chars in (
        ("result_summary", MAX_SUMMARY_CHARS),
        ("error_code", MAX_ID_CHARS),
    ):
        if optional_string in snapshot and snapshot[optional_string] is not None:
            snapshot[optional_string] = _require_string(
                snapshot[optional_string], f"snapshot.{optional_string}", max_chars=max_chars
            )

    warnings = snapshot.get("warnings", [])
    if not isinstance(warnings, list) or any(not isinstance(x, str) for x in warnings):
        raise ContractValidationError("snapshot.warnings: expected string array")
    if any(len(x) > MAX_REASON_CHARS for x in warnings):
        raise ContractValidationError(f"snapshot.warnings: item exceeds {MAX_REASON_CHARS} characters")
    snapshot["warnings"] = list(warnings)

    freeze = snapshot.get("freeze")
    state = snapshot["system_state"]
    status = snapshot["system_status"]

    if state == "FREEZE" or status == "FREEZE":
        if state != "FREEZE" or status != "FREEZE":
            raise ContractValidationError("snapshot: FREEZE state/status must agree")
        if not isinstance(freeze, Mapping):
            raise ContractValidationError("snapshot.freeze: required object in FREEZE")
        freeze = dict(freeze)
        _reject_unknown(freeze, _ALLOWED_FREEZE, "snapshot.freeze")
        _require_keys(
            freeze,
            {"incident_code", "trigger", "blocking_layer", "recoverable", "primary_reason_code"},
            "snapshot.freeze",
        )
        for key in ("incident_code", "trigger", "blocking_layer", "primary_reason_code"):
            freeze[key] = _require_string(
                freeze[key], f"snapshot.freeze.{key}", max_chars=MAX_REASON_CHARS
            )
        if type(freeze["recoverable"]) is not bool:
            raise ContractValidationError("snapshot.freeze.recoverable: expected boolean")
        snapshot["freeze"] = freeze
    elif freeze is not None:
        raise ContractValidationError("snapshot.freeze: forbidden outside FREEZE")

    if state == "STOP" or status == "STOP":
        if state != "STOP" or status != "STOP":
            raise ContractValidationError("snapshot: STOP state/status must agree")
        if snapshot["releaseable"]:
            raise ContractValidationError("snapshot.releaseable: STOP cannot be releaseable")

    if state not in {"FREEZE", "STOP"} and status in {"FREEZE", "STOP"}:
        raise ContractValidationError("snapshot: terminal status/state mismatch")

    verified_count = sum(1 for e in normalized_evidence if e["verified"])
    contradiction_count = sum(1 for e in normalized_evidence if e["contradiction"])

    if snapshot["releaseable"]:
        if state != "STABLE":
            raise ContractValidationError("snapshot.releaseable: only STABLE may be releaseable")
        if not release_policy["passed"]:
            raise ContractValidationError("snapshot.releaseable: release policy has not passed")
        if verified_count < release_policy["evidence_min"]:
            raise ContractValidationError("snapshot.releaseable: verified evidence below policy minimum")
        if contradiction_count:
            raise ContractValidationError("snapshot.releaseable: contradictory evidence forbids release")
        if not snapshot.get("result_summary"):
            raise ContractValidationError("snapshot.result_summary: required for releaseable STABLE result")
    elif snapshot.get("result_summary") is not None:
        raise ContractValidationError("snapshot.result_summary: forbidden when output is not releaseable")

    if state in {"FREEZE", "STOP"} and release_policy["passed"]:
        raise ContractValidationError("snapshot.release_policy.passed: cannot pass in FREEZE/STOP")

    return snapshot
