from __future__ import annotations

from typing import Any

from .canonical import sha256_hex
from .compiler import compile_contract
from .constants import POLICY_VERSION, ROLES, SURFACES, SYSTEM_STATES

_MATRIX_TIME = "2000-01-01T00:00:00Z"


def _baseline_snapshot(state: str, role: str, surface: str) -> dict[str, Any]:
    status = "OK"
    snapshot: dict[str, Any] = {
        "request_id": f"matrix/{state}/{role}/{surface}",
        "trace_id": f"matrix/{state}/{role}/{surface}",
        "observed_at": _MATRIX_TIME,
        "system_status": status,
        "system_state": state,
        "actor_role": role,
        "surface": surface,
        "releaseable": False,
        "release_policy": {"passed": False, "evidence_min": 2},
        "evidence": [],
        "warnings": [],
    }
    if state == "FREEZE":
        snapshot["system_status"] = "FREEZE"
        snapshot["error_code"] = "MATRIX_FREEZE"
        snapshot["freeze"] = {
            "incident_code": "FRZ-MATRIX",
            "trigger": "synthetic-policy-matrix",
            "blocking_layer": "CORE",
            "recoverable": True,
            "primary_reason_code": "MATRIX_FREEZE",
        }
    elif state == "STOP":
        snapshot["system_status"] = "STOP"
        snapshot["error_code"] = "MATRIX_STOP"
    return snapshot


def export_policy_matrix() -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for state in sorted(SYSTEM_STATES):
        for role in sorted(ROLES):
            for surface in sorted(SURFACES):
                contract = compile_contract(_baseline_snapshot(state, role, surface))
                rows.append(
                    {
                        "state": state,
                        "role": role,
                        "surface": surface,
                        "message_key": contract["presentation"]["message_key"],
                        "trace_visible": contract["diagnostics"]["trace_visible"],
                        "actions": contract["actions"],
                    }
                )

    body: dict[str, Any] = {
        "artifact_type": "NOCC_POLICY_MATRIX",
        "policy_version": POLICY_VERSION,
        "scenario_count": len(rows),
        "dimensions": {
            "states": sorted(SYSTEM_STATES),
            "roles": sorted(ROLES),
            "surfaces": sorted(SURFACES),
        },
        "rows": rows,
    }
    body["matrix_sha256"] = sha256_hex(body)
    return body
