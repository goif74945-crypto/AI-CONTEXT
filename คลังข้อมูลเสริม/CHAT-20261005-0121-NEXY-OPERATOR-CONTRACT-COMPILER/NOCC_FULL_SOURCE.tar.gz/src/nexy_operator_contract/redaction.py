from __future__ import annotations

import re
from collections.abc import Callable

Replacement = str | Callable[[re.Match[str]], str]

_REDACTION_RULES: tuple[tuple[re.Pattern[str], Replacement], ...] = (
    (re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._~+\-/]+=*"), "Bearer [REDACTED]"),
    (re.compile(r"\bsk-[A-Za-z0-9_-]{12,}\b"), "sk-[REDACTED]"),
    (
        re.compile(r"(?i)\b(api[_-]?key|password|passwd|secret|token)\s*[:=]\s*[^\s,;]+"),
        lambda m: f"{m.group(1)}=[REDACTED]",
    ),
)


def redact_sensitive_text(value: str) -> str:
    """Best-effort presentation redaction; not a substitute for upstream secret controls."""
    result = value
    for pattern, replacement in _REDACTION_RULES:
        result = pattern.sub(replacement, result)
    return result
