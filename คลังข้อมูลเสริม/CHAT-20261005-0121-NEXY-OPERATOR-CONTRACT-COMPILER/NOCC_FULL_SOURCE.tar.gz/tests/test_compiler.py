from __future__ import annotations

import copy
import json
import os
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from nexy_operator_contract import (  # noqa: E402
    ContractValidationError,
    compile_contract,
    verify_compiled_contract,
)
from nexy_operator_contract.constants import MUTATING_ACTIONS, ROLES, SYSTEM_STATES  # noqa: E402
from nexy_operator_contract.redaction import redact_sensitive_text  # noqa: E402


def fixture(name: str) -> dict:
    return json.loads((ROOT / "fixtures" / name).read_text(encoding="utf-8"))


def snapshot_for(state: str, role: str = "OWNER") -> dict:
    status = "OK"
    freeze = None
    error_code = None
    if state == "FREEZE":
        status = "FREEZE"
        freeze = {
            "incident_code": "FRZ-X",
            "trigger": "test",
            "blocking_layer": "CORE",
            "recoverable": True,
            "primary_reason_code": "TEST_FREEZE",
        }
        error_code = "TEST_FREEZE"
    elif state == "STOP":
        status = "STOP"
        error_code = "TEST_STOP"

    data = {
        "request_id": f"req-{state.lower()}-{role.lower()}",
        "trace_id": f"trace-{state.lower()}-{role.lower()}",
        "observed_at": "2026-10-05T01:40:00+07:00",
        "system_status": status,
        "system_state": state,
        "actor_role": role,
        "surface": "RUN",
        "releaseable": False,
        "release_policy": {"passed": False, "evidence_min": 2},
        "evidence": [],
        "warnings": [],
    }
    if freeze is not None:
        data["freeze"] = freeze
    if error_code is not None:
        data["error_code"] = error_code
    return data


class CompilerHappyPathTests(unittest.TestCase):
    def test_stable_release_emits_result_and_hash(self) -> None:
        contract = compile_contract(fixture("stable_owner.json"))
        self.assertTrue(verify_compiled_contract(contract))
        self.assertEqual(contract["truth"]["system_state"], "STABLE")
        self.assertEqual(contract["presentation"]["message_key"], "VERIFIED_RESULT_AVAILABLE")
        actions = {a["action_id"]: a for a in contract["actions"]}
        self.assertTrue(actions["VIEW_RESULT"]["executable"])
        self.assertTrue(actions["EXPORT_RESULT"]["executable"])
        self.assertEqual(len(contract["contract_sha256"]), 64)

    def test_ready_operator_can_submit_and_save(self) -> None:
        contract = compile_contract(fixture("ready_operator.json"))
        actions = {a["action_id"]: a for a in contract["actions"]}
        self.assertTrue(actions["SUBMIT_DIRECTIVE"]["executable"])
        self.assertTrue(actions["SAVE_DRAFT"]["editable"])

    def test_freeze_owner_recovery_is_explicit(self) -> None:
        contract = compile_contract(fixture("freeze_owner.json"))
        actions = {a["action_id"]: a for a in contract["actions"]}
        self.assertFalse(contract["truth"]["releaseable"])
        self.assertEqual(contract["presentation"]["message_key"], "SYSTEM_FROZEN")
        self.assertTrue(actions["RECOVER"]["visible"])
        self.assertTrue(actions["RECOVER"]["executable"])
        self.assertEqual(contract["freeze"]["incident_code"], "FRZ-001")

    def test_nonrecoverable_freeze_disables_recover(self) -> None:
        data = fixture("freeze_owner.json")
        data["freeze"]["recoverable"] = False
        contract = compile_contract(data)
        recover = next(a for a in contract["actions"] if a["action_id"] == "RECOVER")
        self.assertTrue(recover["visible"])
        self.assertFalse(recover["executable"])
        self.assertIn("FREEZE_NOT_RECOVERABLE", recover["reason_codes"])

    def test_stop_exposes_no_mutating_action(self) -> None:
        contract = compile_contract(fixture("stop_owner.json"))
        self.assertTrue(verify_compiled_contract(contract))
        for action in contract["actions"]:
            if action["action_id"] in MUTATING_ACTIONS:
                self.assertFalse(action["executable"])


class TruthBoundaryTests(unittest.TestCase):
    def test_unknown_top_level_field_fails_closed(self) -> None:
        data = fixture("ready_operator.json")
        data["surprise"] = "guess me"
        with self.assertRaises(ContractValidationError):
            compile_contract(data)

    def test_freeze_metadata_is_mandatory(self) -> None:
        data = fixture("freeze_owner.json")
        del data["freeze"]["blocking_layer"]
        with self.assertRaises(ContractValidationError):
            compile_contract(data)

    def test_freeze_status_state_must_agree(self) -> None:
        data = fixture("freeze_owner.json")
        data["system_status"] = "OK"
        with self.assertRaises(ContractValidationError):
            compile_contract(data)

    def test_releaseable_requires_stable(self) -> None:
        data = fixture("ready_operator.json")
        data["releaseable"] = True
        data["release_policy"] = {"passed": True, "evidence_min": 0}
        data["result_summary"] = "invalid"
        with self.assertRaises(ContractValidationError):
            compile_contract(data)

    def test_unreleased_result_summary_is_forbidden(self) -> None:
        data = fixture("ready_operator.json")
        data["result_summary"] = "looks done"
        with self.assertRaises(ContractValidationError):
            compile_contract(data)

    def test_releaseable_rejects_contradictory_evidence(self) -> None:
        data = fixture("stable_owner.json")
        data["evidence"][0]["contradiction"] = True
        with self.assertRaises(ContractValidationError):
            compile_contract(data)

    def test_releaseable_rejects_insufficient_verified_evidence(self) -> None:
        data = fixture("stable_owner.json")
        data["release_policy"]["evidence_min"] = 3
        with self.assertRaises(ContractValidationError):
            compile_contract(data)

    def test_release_policy_cannot_pass_in_stop(self) -> None:
        data = fixture("stop_owner.json")
        data["release_policy"]["passed"] = True
        with self.assertRaises(ContractValidationError):
            compile_contract(data)


class DeterminismAndTamperTests(unittest.TestCase):
    def test_evidence_order_does_not_change_output_hash(self) -> None:
        a = fixture("stable_owner.json")
        b = copy.deepcopy(a)
        b["evidence"] = list(reversed(b["evidence"]))
        ca = compile_contract(a)
        cb = compile_contract(b)
        self.assertEqual(ca, cb)
        self.assertEqual(ca["contract_sha256"], cb["contract_sha256"])

    def test_material_change_changes_hash(self) -> None:
        a = fixture("stable_owner.json")
        b = copy.deepcopy(a)
        b["actor_role"] = "AUDITOR"
        self.assertNotEqual(
            compile_contract(a)["contract_sha256"],
            compile_contract(b)["contract_sha256"],
        )

    def test_tamper_breaks_verification(self) -> None:
        contract = compile_contract(fixture("stable_owner.json"))
        contract["presentation"]["message_key"] = "FAKE_SUCCESS"
        self.assertFalse(verify_compiled_contract(contract))


class PermissionMatrixTests(unittest.TestCase):
    def test_read_only_roles_never_execute_mutating_actions_across_all_states(self) -> None:
        for role in ("AUDITOR", "PUBLIC_USER"):
            for state in sorted(SYSTEM_STATES):
                with self.subTest(role=role, state=state):
                    contract = compile_contract(snapshot_for(state, role))
                    for action in contract["actions"]:
                        if action["action_id"] in MUTATING_ACTIONS:
                            self.assertFalse(action["executable"])

    def test_stop_never_executes_mutating_actions_for_any_role(self) -> None:
        for role in sorted(ROLES):
            with self.subTest(role=role):
                contract = compile_contract(snapshot_for("STOP", role))
                for action in contract["actions"]:
                    if action["action_id"] in MUTATING_ACTIONS:
                        self.assertFalse(action["executable"])

    def test_only_owner_can_execute_recover(self) -> None:
        for role in sorted(ROLES):
            with self.subTest(role=role):
                contract = compile_contract(snapshot_for("FREEZE", role))
                recover = next((a for a in contract["actions"] if a["action_id"] == "RECOVER"), None)
                if role == "OWNER":
                    self.assertIsNotNone(recover)
                    self.assertTrue(recover["executable"])
                else:
                    self.assertIsNotNone(recover)
                    self.assertFalse(recover["executable"])


class RedactionTests(unittest.TestCase):
    def test_common_secret_shapes_are_redacted(self) -> None:
        source = "Bearer abc.DEF-123 token=supersecret sk-abcdefghijklmnop"
        redacted = redact_sensitive_text(source)
        self.assertNotIn("abc.DEF-123", redacted)
        self.assertNotIn("supersecret", redacted)
        self.assertNotIn("abcdefghijklmnop", redacted)
        self.assertIn("[REDACTED]", redacted)

    def test_compiler_redacts_presentation_and_evidence(self) -> None:
        data = fixture("stable_owner.json")
        data["result_summary"] = "token=secret123 artifact ready"
        data["evidence"][0]["summary"] = "Bearer abcdefghijklmnop"
        contract = compile_contract(data)
        serialized = json.dumps(contract)
        self.assertNotIn("secret123", serialized)
        self.assertNotIn("abcdefghijklmnop", serialized)


class SchemaAndCliTests(unittest.TestCase):
    def test_schema_documents_are_valid_json(self) -> None:
        for name in ("input.schema.json", "output.schema.json"):
            parsed = json.loads((ROOT / "schemas" / name).read_text(encoding="utf-8"))
            self.assertEqual(parsed["type"], "object")
            self.assertFalse(parsed["additionalProperties"])

    def test_cli_success_fixture(self) -> None:
        env = os.environ.copy()
        env["PYTHONPATH"] = str(SRC)
        proc = subprocess.run(
            [sys.executable, "-m", "nexy_operator_contract.cli", str(ROOT / "fixtures" / "stable_owner.json")],
            cwd=ROOT,
            env=env,
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(proc.returncode, 0, proc.stderr)
        output = json.loads(proc.stdout)
        self.assertTrue(verify_compiled_contract(output))

    def test_cli_validation_failure_is_nonzero(self) -> None:
        invalid = ROOT / "fixtures" / "_invalid_temp.json"
        invalid.write_text("{}", encoding="utf-8")
        self.addCleanup(lambda: invalid.unlink(missing_ok=True))
        env = os.environ.copy()
        env["PYTHONPATH"] = str(SRC)
        proc = subprocess.run(
            [sys.executable, "-m", "nexy_operator_contract.cli", str(invalid)],
            cwd=ROOT,
            env=env,
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(proc.returncode, 2)
        err = json.loads(proc.stderr)
        self.assertEqual(err["status"], "FAIL")


if __name__ == "__main__":
    unittest.main()
