from __future__ import annotations

import copy
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from nexy_operator_contract import ContractValidationError, compile_contract, verify_compiled_contract  # noqa: E402
from nexy_operator_contract.constants import ROLES, SURFACES, SYSTEM_STATES  # noqa: E402


def base_snapshot(state: str, role: str, surface: str) -> dict:
    status = "OK"
    data = {
        "request_id": f"req-{state}-{role}-{surface}",
        "trace_id": f"trace-{state}-{role}-{surface}",
        "observed_at": "2026-10-05T01:45:00+07:00",
        "system_status": status,
        "system_state": state,
        "actor_role": role,
        "surface": surface,
        "releaseable": False,
        "release_policy": {"passed": False, "evidence_min": 2},
        "evidence": [],
        "warnings": [],
    }
    if state == "FREEZE":
        data["system_status"] = "FREEZE"
        data["error_code"] = "TEST_FREEZE"
        data["freeze"] = {
            "incident_code": "FRZ-MATRIX",
            "trigger": "matrix-test",
            "blocking_layer": "CORE",
            "recoverable": True,
            "primary_reason_code": "TEST_FREEZE",
        }
    elif state == "STOP":
        data["system_status"] = "STOP"
        data["error_code"] = "TEST_STOP"
    return data


class ExhaustiveContractMatrixTests(unittest.TestCase):
    def test_all_120_state_role_surface_nonrelease_scenarios_compile(self) -> None:
        count = 0
        for state in sorted(SYSTEM_STATES):
            for role in sorted(ROLES):
                for surface in sorted(SURFACES):
                    with self.subTest(state=state, role=role, surface=surface):
                        contract = compile_contract(base_snapshot(state, role, surface))
                        self.assertTrue(verify_compiled_contract(contract))
                        self.assertEqual(contract["truth"]["system_state"], state)
                        self.assertEqual(contract["operator"]["role"], role)
                        self.assertEqual(contract["operator"]["surface"], surface)
                        count += 1
        self.assertEqual(count, 120)

    def test_action_shape_invariants_hold_for_full_matrix(self) -> None:
        for state in sorted(SYSTEM_STATES):
            for role in sorted(ROLES):
                for surface in sorted(SURFACES):
                    contract = compile_contract(base_snapshot(state, role, surface))
                    ids = [a["action_id"] for a in contract["actions"]]
                    self.assertEqual(ids, sorted(ids))
                    self.assertEqual(len(ids), len(set(ids)))
                    for action in contract["actions"]:
                        if action["editable"] or action["executable"]:
                            self.assertTrue(action["visible"])

    def test_ready_view_surface_never_exposes_write_controls(self) -> None:
        for role in sorted(ROLES):
            contract = compile_contract(base_snapshot("READY", role, "VIEW"))
            ids = {a["action_id"] for a in contract["actions"] if a["visible"]}
            self.assertNotIn("SUBMIT_DIRECTIVE", ids)
            self.assertNotIn("SAVE_DRAFT", ids)

    def test_ready_run_write_controls_are_owner_operator_only(self) -> None:
        for role in sorted(ROLES):
            contract = compile_contract(base_snapshot("READY", role, "RUN"))
            executable = {a["action_id"] for a in contract["actions"] if a["executable"]}
            if role in {"OWNER", "OPERATOR"}:
                self.assertIn("SUBMIT_DIRECTIVE", executable)
                self.assertIn("SAVE_DRAFT", executable)
            else:
                self.assertNotIn("SUBMIT_DIRECTIVE", executable)
                self.assertNotIn("SAVE_DRAFT", executable)

    def test_stable_release_export_role_policy(self) -> None:
        for role in sorted(ROLES):
            data = base_snapshot("STABLE", role, "VIEW")
            data["releaseable"] = True
            data["release_policy"] = {"passed": True, "evidence_min": 2}
            data["result_summary"] = "verified"
            data["evidence"] = [
                {"id": "a", "verified": True, "contradiction": False},
                {"id": "b", "verified": True, "contradiction": False},
            ]
            contract = compile_contract(data)
            actions = {a["action_id"]: a for a in contract["actions"]}
            self.assertTrue(actions["VIEW_RESULT"]["executable"])
            if role in {"OWNER", "OPERATOR", "AUDITOR"}:
                self.assertTrue(actions["EXPORT_RESULT"]["executable"])
            else:
                self.assertIn("EXPORT_RESULT", actions)
                self.assertFalse(actions["EXPORT_RESULT"]["visible"])
                self.assertFalse(actions["EXPORT_RESULT"]["executable"])
                self.assertIn("ROLE_EXPORT_FORBIDDEN", actions["EXPORT_RESULT"]["reason_codes"])

    def test_repeated_compilation_is_byte_semantically_identical(self) -> None:
        data = base_snapshot("FREEZE", "OWNER", "RUN")
        first = compile_contract(copy.deepcopy(data))
        for _ in range(20):
            self.assertEqual(first, compile_contract(copy.deepcopy(data)))


class StrictInputTests(unittest.TestCase):
    def test_unknown_nested_release_policy_field_rejected(self) -> None:
        data = base_snapshot("READY", "OWNER", "RUN")
        data["release_policy"]["confidence"] = 1.0
        with self.assertRaises(ContractValidationError):
            compile_contract(data)

    def test_unknown_nested_evidence_field_rejected(self) -> None:
        data = base_snapshot("STABLE", "OWNER", "VIEW")
        data["evidence"] = [
            {"id": "x", "verified": False, "contradiction": False, "authority": "invented"}
        ]
        with self.assertRaises(ContractValidationError):
            compile_contract(data)

    def test_duplicate_evidence_id_rejected(self) -> None:
        data = base_snapshot("STABLE", "OWNER", "VIEW")
        data["evidence"] = [
            {"id": "x", "verified": False, "contradiction": False},
            {"id": "x", "verified": True, "contradiction": False},
        ]
        with self.assertRaises(ContractValidationError):
            compile_contract(data)

    def test_boolean_is_not_accepted_as_integer_evidence_min(self) -> None:
        data = base_snapshot("READY", "OWNER", "RUN")
        data["release_policy"]["evidence_min"] = True
        with self.assertRaises(ContractValidationError):
            compile_contract(data)

class PolicyMatrixArtifactTests(unittest.TestCase):
    def test_exported_policy_matrix_is_complete_and_deterministic(self) -> None:
        from nexy_operator_contract.matrix import export_policy_matrix

        a = export_policy_matrix()
        b = export_policy_matrix()
        self.assertEqual(a, b)
        self.assertEqual(a["scenario_count"], 120)
        self.assertEqual(len(a["rows"]), 120)
        self.assertEqual(len(a["matrix_sha256"]), 64)

    def test_policy_matrix_rows_are_unique(self) -> None:
        from nexy_operator_contract.matrix import export_policy_matrix

        matrix = export_policy_matrix()
        keys = {(r["state"], r["role"], r["surface"]) for r in matrix["rows"]}
        self.assertEqual(len(keys), 120)

if __name__ == "__main__":
    unittest.main()
